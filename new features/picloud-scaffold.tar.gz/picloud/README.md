# PiCloud

> A private cloud that runs on Raspberry Pi hardware.  
> One binary. Zero dependencies. Add nodes, gain capacity.

---

## Vision

PiCloud turns a cluster of Raspberry Pi 5 nodes into a private cloud — one that you own completely, runs on hardware that fits in a shoebox, and grows by simply plugging in another Pi.

The platform runs as a single binary on every node. There is no control plane to manage, no infrastructure to run the infrastructure, no configuration to update when you add a node. A node joins the network, announces itself, and immediately participates in compute, storage, and identity. Capabilities come from the platform — not from the operator.

Applications are deployed as **Products** — versioned, hermetically sealed units that own their compute, storage, identity, and data. Products never share resources. They communicate exclusively through events and semantic graph queries. The platform enforces this at the network level, not by convention.

PiCloud is designed to be built and extended by LLMs. Every architectural decision is documented and justified. The entire cluster state is a queryable knowledge graph. The platform is the documentation.

---

## What Makes It Different

Most self-hosted platforms are Kubernetes with the rough edges sanded down. PiCloud is built on a different set of ideas:

### The cluster is a living event stream

State is never stored directly. Every operation — node joins, deployments, identity changes, storage allocations — is appended to an immutable, Raft-replicated event log. Nothing is ever written to a database. If you want to know the current state of anything, you query the projection of that log.

This means the cluster has a complete, permanent record of everything that has ever happened. Point-in-time reconstruction, full audit trails, and time-travel queries are properties of the architecture — not features you enable.

### The RDF graph is the read model

The cluster's observable state is an RDF knowledge graph, maintained by projectors that continuously consume the event log. State reads are SPARQL queries. Every resource, relationship, and status in the cluster is a triple.

This makes the cluster semantically discoverable. You can ask it questions like *"which products subscribe to events from user-service?"* or *"which nodes are running workloads that mount volumes with full-replication?"* — without any special tooling. Any SPARQL client works. So does any LLM.

### Every resource has a dereferenceable IRI

```
https://picloud.local/products/photo-app/containers/api-server
https://picloud.local/products/photo-app/graph
https://picloud.local/products/photo-app/ontology
```

Every resource in the cluster has an address that is both its unique identifier and its network location. HTTP content negotiation returns Turtle, JSON-LD, or JSON depending on what you ask for. The cluster root returns a description of everything deployed on it. There is no service catalog to maintain — the cluster is the catalog.

### Products are hermetically sealed deployment units

A Product is a deployment boundary that contains everything an application needs: containers, block storage, workload identities, an RDF store, an event bus, and a SPARQL endpoint. Products are versioned. One active version runs at a time. Upgrades are atomic — the new version reaches fully ready before the old one is torn down.

Products communicate with each other exclusively through declared event subscriptions and SPARQL graph queries. Direct network calls between Products are not routed by the platform. This is enforced at the infrastructure level, not by convention or code review.

### The platform is the identity provider

PiCloud is a full OIDC provider. Human users authenticate with passkeys and FIDO2 — no passwords exist anywhere in the system. Products act as OIDC App Registrations. Applications built on PiCloud get SSO, token management, and user management without any external identity service.

Workloads receive mTLS certificates injected by the platform at runtime. They never handle credential generation.

### Event sourcing is a first-class developer primitive

Every Product can declare a managed event store. The platform provisions the event log, manages aggregate streams, serves versioned schema IRIs, and automatically projects aggregate events into the Product's RDF store. Developers get event sourcing without building the infrastructure for it.

### SDKs are generated from the platform's own ontology

The platform's RDF ontology is the source of truth for the entire API surface. SDKs in Rust, TypeScript, and .NET are generated from that ontology and published to crates.io, npm, and NuGet on every platform release. The SDK cannot drift from the API — they are derived from the same source.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│  picloud CLI                                                     │
│  Emits command events → subscribes to result stream via SSE      │
├──────────────────────────────────────────────────────────────────┤
│  HTTP / IRI Layer                                                │
│  Every resource is an HTTPS endpoint with content negotiation    │
│  https://picloud.local/{resource-path}                           │
├──────────────────────────────────────────────────────────────────┤
│  Platform Services                                               │
│  IAM (OIDC + WebAuthn)  ·  DNS  ·  Ingress  ·  mTLS             │
├──────────────────────────────────────────────────────────────────┤
│  Product Runtime                                                 │
│  Workload scheduler  ·  Block storage  ·  Event bus              │
│  Per-product: SPARQL endpoint  ·  Event store  ·  Ontology       │
├──────────────────────────────────────────────────────────────────┤
│  Event Log  ──────────►  RDF Projector  ──────────►  Oxigraph    │
│  Append-only, Raft-replicated              Queryable via SPARQL  │
├──────────────────────────────────────────────────────────────────┤
│  Raft Consensus (openraft)                                       │
│  Leader election  ·  Log replication  ·  Node membership         │
├──────────────────────────────────────────────────────────────────┤
│  mDNS Node Discovery                                             │
│  Nodes find each other automatically  ·  picloud.local resolves  │
└──────────────────────────────────────────────────────────────────┘
```

Every command follows the same path:

1. CLI emits a command event with a correlation ID
2. Raft leader appends it to the replicated event log
3. RDF projector updates the Oxigraph graph
4. CLI subscribes to the result stream and receives progress events in real time
5. A terminal event (`ResourceReady` or `ResourceFailed`) completes the operation

---

## Stack

| Concern | Choice | Why |
|---|---|---|
| Language | Rust | Single ARM64 binary, no GC, memory safety for storage paths |
| Consensus | openraft | Pure Rust Raft implementation, pluggable storage and transport |
| RDF / SPARQL | Oxigraph | Pure Rust, embedded, full SPARQL 1.1, named graph support |
| Node discovery | mDNS (mdns-sd) | Zero config — `.local` resolves on every modern OS automatically |
| OCI runtime | youki | Pure Rust OCI runtime, no Docker daemon |
| HTTP | axum | Ergonomic, tower-compatible, good content negotiation support |
| Auth | WebAuthn / FIDO2 | Passkeys only — no passwords anywhere in the system |

The full dependency stack is Rust-native. No JVM, no Go runtime, no external processes.

---

## Resource Model

Everything in PiCloud is a resource declared in a `.picloud` file:

```bicep
product 'photo-app' = {
  version: '1.0.0'
  description: 'Photo sharing application'
}

volume 'media-store' = {
  product: 'photo-app'
  size: '100GB'
  storageIntent: {
    durability: 'full-replication'
    performance: 'standard'
  }
}

event-store 'photos' = {
  product: 'photo-app'
  aggregates: [
    { type: 'Photo', schema: 'schemas/photo-events.ttl' }
    { type: 'Album', schema: 'schemas/album-events.ttl' }
  ]
}

container 'api-server' = {
  product: 'photo-app'
  image: 'photo-api:1.0.0'
  identity: 'api-worker'
  mounts: [
    { volume: 'media-store', path: '/data' }
  ]
}
```

Deploy it:

```bash
picloud resource apply ./photo-app/
```

Watch it happen:

```
→ ResourceDeclared:     photo-app
→ ResourceDeclared:     media-store
→ ResourceProvisioning: media-store  (allocating 100GB across 5 nodes)
→ ResourceReady:        media-store
→ ResourceDeclared:     api-server
→ ResourceProvisioning: api-server   (scheduling on pi-node-03)
→ ResourceReady:        api-server
✓ photo-app deployed
```

---

## Getting Started

### Prerequisites

- 1–5 Raspberry Pi 5 nodes, 16GB RAM, 1TB NVMe each
- Ubuntu Server 64-bit (ARM64) on each node
- A dev machine with Rust installed

### Install cross-compilation tooling

```bash
cargo install cross
rustup target add aarch64-unknown-linux-gnu
```

### Set up SSH access

```bash
cp deploy/ssh-config.example ~/.ssh/config
# Edit the file — fill in the IP address for each Pi
```

### One-time node setup

Run once per Pi to install `avahi-daemon` (mDNS) and configure ports:

```bash
ssh ubuntu@<pi-ip> 'bash -s' < deploy/setup-node.sh
```

### Bootstrap the cluster

On the first Pi:

```bash
picloud cluster init
```

This generates a bootstrap token and prints an enrollment URL. Open it in a browser and register your passkey. That creates the first admin identity.

Remaining nodes join automatically via mDNS — just start the service and they find the cluster.

### Deploy

```bash
# Build and deploy to all nodes
./deploy/deploy.sh

# Deploy to one node
./deploy/deploy.sh pi-01

# Build only — no deploy
./deploy/deploy.sh --check
```

### Watch logs

```bash
# All nodes, colour-coded
./deploy/logs.sh

# Errors only
./deploy/logs.sh --errors

# One node
./deploy/logs.sh pi-03
```

---

## Development

### Repository layout

```
picloud/
├── CLAUDE.md               ← Start here when using Claude Code
├── docs/
│   ├── picloud-prd.md      ← Product requirements
│   └── picloud-adrs.md     ← Architecture decisions (34 ADRs)
├── crates/
│   ├── picloud-domain/     ← Shared types, traits, IRI model (no implementations)
│   ├── picloud-cluster/    ← mDNS + Raft
│   ├── picloud-events/     ← Event log + product event stores
│   ├── picloud-rdf/        ← Oxigraph projection + SPARQL
│   ├── picloud-iam/        ← OIDC + WebAuthn + workload certs
│   ├── picloud-storage/    ← Block storage + volume allocation
│   ├── picloud-workload/   ← OCI containers + binary scheduler
│   ├── picloud-network/    ← DNS + mTLS + ingress
│   ├── picloud-http/       ← HTTP server + IRI routing
│   ├── picloud-sdk-gen/    ← SDK generator (Rust, TypeScript, .NET)
│   └── picloud-cli/        ← CLI binary
└── src/
    └── main.rs             ← Server binary — composition root only
```

### Dependency rule

```
picloud-domain  ←  no internal dependencies
all slices      →  picloud-domain only
picloud-server  →  all slices (composition root)
picloud-cli     →  picloud-domain only
```

Slices never import each other. They communicate at runtime through the event log and through domain traits injected at the composition root. This is enforced by `Cargo.toml` — cross-slice imports are impossible to add accidentally.

### Build

```bash
cargo build --workspace
cargo test -p picloud-domain
cargo check --workspace
```

### Build for Pi

```bash
cross build --workspace --target aarch64-unknown-linux-gnu --release
```

---

## Phase Plan

| Phase | Status | Focus |
|---|---|---|
| 1 — Foundation | 🔨 In progress | Cluster formation, IAM, block storage, workload scheduling |
| 2 — Products | ⬜ Planned | Full product lifecycle, OIDC, secrets, atomic upgrades |
| 3 — RDF + Event Store | ⬜ Planned | Per-product SPARQL, event sourcing, SDK generation |
| 4 — Maturity | ⬜ Planned | Storage tiers, log compaction, node drain |

**Phase 1 exit criteria:** Two nodes form a cluster via mDNS, a container runs with a replicated volume mounted, the cluster survives one node restart without data loss.

---

## Documentation

- [Product Requirements Document](docs/picloud-prd.md) — full feature specification
- [Architecture Decision Records](docs/picloud-adrs.md) — every major decision with rationale and rejected alternatives
- [CLAUDE.md](CLAUDE.md) — context file for Claude Code

---

## License

Apache 2.0
