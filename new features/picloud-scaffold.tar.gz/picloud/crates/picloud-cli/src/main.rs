/// PiCloud CLI
///
/// The CLI is the primary management interface for PiCloud (ADR-008).
/// All commands emit events to the cluster and subscribe to the result stream.
/// The CLI never imports slice internals — it only talks HTTP to the cluster.

use clap::{Parser, Subcommand};

mod new_command;

#[derive(Parser)]
#[command(
    name = "picloud",
    about = "PiCloud — private cloud for Raspberry Pi clusters",
    version
)]
struct Cli {
    /// Cluster domain (default: picloud.local)
    #[arg(long, env = "PICLOUD_DOMAIN", default_value = "picloud.local")]
    domain: String,

    /// Path to identity token
    #[arg(long, env = "PICLOUD_TOKEN")]
    token: Option<String>,

    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Cluster management
    Cluster {
        #[command(subcommand)]
        command: ClusterCommands,
    },
    /// Resource operations
    Resource {
        #[command(subcommand)]
        command: ResourceCommands,
    },
    /// Volume snapshot and backup management
    Volume {
        #[command(subcommand)]
        command: VolumeCommands,
    },
    /// Identity and access management
    Identity {
        #[command(subcommand)]
        command: IdentityCommands,
    },
    /// Event stream subscription
    Events {
        #[command(subcommand)]
        command: EventCommands,
    },
    /// Event replay
    Replay {
        #[command(subcommand)]
        command: ReplayCommands,
    },
    /// Graph queries
    Graph {
        #[command(subcommand)]
        command: GraphCommands,
    },
    /// Generate a new resource file interactively
    New {
        #[command(subcommand)]
        command: NewCommands,
    },
    /// Compile and validate .picloud / .ttl resource files
    Compile {
        #[command(subcommand)]
        command: CompileCommands,
    },
    /// Generate documentation from platform ontology
    Docs {
        #[command(subcommand)]
        command: DocsCommands,
    },
        #[command(subcommand)]
        command: CaCommands,
    },
    /// SDK generation and publication
    Sdk {
        #[command(subcommand)]
        command: SdkCommands,
    },
}

#[derive(Subcommand)]
enum ClusterCommands {
    /// Bootstrap a new cluster on this node
    Init {
        /// Cluster domain — the tenant identity and root of all IRIs
        /// Defaults to picloud.local for single-tenant home lab use
        #[arg(long, default_value = "picloud.local")]
        domain: String,
        /// Path to BYO CA certificate in PEM format (ADR-030)
        /// If omitted, the platform generates its own CA
        #[arg(long)]
        ca_cert: Option<String>,
        /// Path to BYO CA private key in PEM format
        /// Required when --ca-cert is provided
        #[arg(long)]
        ca_key: Option<String>,
    },
    /// Physical recovery — generate a new bootstrap token from a node
    Recover,
    /// Show cluster status
    Status,
}

#[derive(Subcommand)]
enum VolumeCommands {
    /// List available snapshots for a volume
    Snapshots {
        /// Volume name (e.g. photo-app/family-photos)
        volume: String,
    },
    /// Restore a volume from a snapshot or offsite backup
    Restore {
        /// Volume name
        volume: String,
        /// Snapshot timestamp to restore from
        #[arg(long)]
        snapshot: Option<String>,
        /// Restore from offsite backup by date
        #[arg(long)]
        date: Option<String>,
        /// Restore from offsite (vs local NAS snapshot)
        #[arg(long)]
        offsite: bool,
        /// Name for the restored volume
        #[arg(long)]
        target: String,
    },
    /// Trigger an immediate snapshot
    Snapshot {
        volume: String,
    },
    /// Trigger an immediate offsite backup
    Backup {
        volume: String,
    },
    /// Show snapshot and backup status for a volume
    Status {
        volume: String,
    },
}

#[derive(Subcommand)]
enum ResourceCommands {
    /// Apply all .picloud resource files in a directory
    Apply {
        /// Path to directory containing .picloud files
        path: String,
    },
    /// Delete all resources declared in a directory
    Delete {
        path: String,
    },
    /// Show resource status
    Status {
        /// Product name or resource IRI
        target: String,
    },
}

#[derive(Subcommand)]
enum IdentityCommands {
    /// Create a human identity
    Create {
        #[arg(long)]
        name: String,
        #[arg(long)]
        email: Option<String>,
    },
    /// Initiate passkey reset for a user (admin only)
    ResetPasskey {
        /// Identity name or IRI
        identity: String,
    },
    /// Get a CLI token for the current user (device flow or FIDO2 direct)
    Token,
}

#[derive(Subcommand)]
enum ReplayCommands {
    /// Replay the platform event log
    Cluster {
        #[arg(long)]
        from: String,
        #[arg(long)]
        to: Option<String>,
    },
    /// Replay a product's full event store
    Product {
        /// Product name
        name: String,
        #[arg(long)]
        from: String,
        #[arg(long)]
        to: Option<String>,
    },
    /// Replay a specific aggregate
    Aggregate {
        /// Product name
        product: String,
        #[arg(long)]
        store: String,
        #[arg(long, name = "type")]
        aggregate_type: String,
        #[arg(long)]
        id: String,
        #[arg(long)]
        from: String,
        #[arg(long)]
        to: Option<String>,
    },
    /// Replay a batch of aggregates from a file (one UUID per line, max 1000)
    Batch {
        /// Product name
        product: String,
        #[arg(long)]
        store: String,
        #[arg(long, name = "type")]
        aggregate_type: String,
        /// Path to file containing aggregate IDs (one UUID per line)
        #[arg(long)]
        ids_file: String,
        #[arg(long)]
        from: String,
        #[arg(long)]
        to: Option<String>,
    },
    /// Check status of a running replay
    Status {
        replay_id: String,
    },
    /// Cancel a running replay
    Cancel {
        replay_id: String,
    },
}

#[derive(Subcommand)]
    /// Subscribe to the platform event stream
    Stream {
        /// Filter to a specific product
        #[arg(long)]
        product: Option<String>,
        /// Filter to a specific correlation ID
        #[arg(long)]
        correlation_id: Option<String>,
    },
}

#[derive(Subcommand)]
enum GraphCommands {
    /// Execute a SPARQL query against the cluster graph
    Query {
        #[arg(long)]
        sparql: String,
        /// Scope to a specific product graph
        #[arg(long)]
        product: Option<String>,
    },
}

#[derive(Subcommand)]
enum NewCommands {
    /// Generate a new product resource file
    Product {
        #[arg(long)] name:        Option<String>,
        #[arg(long)] version:     Option<String>,
        #[arg(long)] description: Option<String>,
        #[arg(long)] output:      Option<String>,
        #[arg(long)] overwrite:   bool,
    },
    /// Generate a new container resource file
    Container {
        #[arg(long)] product:   Option<String>,
        #[arg(long)] name:      Option<String>,
        #[arg(long)] image:     Option<String>,
        #[arg(long)] identity:  Option<String>,
        /// Mount in volume:path format (e.g. media-store:/data)
        #[arg(long)] mount:     Vec<String>,
        /// Tag in key=value format (e.g. team=backend)
        #[arg(long)] tag:       Vec<String>,
        #[arg(long)] cpu:       Option<u32>,
        #[arg(long)] memory:    Option<u32>,
        #[arg(long)] output:    Option<String>,
        #[arg(long)] overwrite: bool,
    },
    /// Generate a new volume resource file
    Volume {
        #[arg(long)] product:    Option<String>,
        #[arg(long)] name:       Option<String>,
        #[arg(long)] size:       Option<String>,
        #[arg(long)] durability: Option<String>,
        #[arg(long)] snapshots:  bool,
        #[arg(long)] offsite:    bool,
        #[arg(long)] tag:        Vec<String>,
        #[arg(long)] output:     Option<String>,
        #[arg(long)] overwrite:  bool,
    },
    /// Generate a new feature flag resource file
    FeatureFlag {
        #[arg(long)] product:     Option<String>,
        #[arg(long)] name:        Option<String>,
        #[arg(long)] enabled:     Option<bool>,
        /// Version expression (e.g. ">= 2", "= 2", "2..4")
        #[arg(long)] version:     Option<String>,
        #[arg(long)] description: Option<String>,
        #[arg(long)] output:      Option<String>,
        #[arg(long)] overwrite:   bool,
    },
    /// Generate a new ingress resource file
    Ingress {
        #[arg(long)] product:   Option<String>,
        #[arg(long)] name:      Option<String>,
        #[arg(long)] target:    Option<String>,
        #[arg(long)] port:      Option<u16>,
        #[arg(long)] host:      Option<String>,
        #[arg(long)] tls:       bool,
        #[arg(long)] internal:  bool,
        #[arg(long)] output:    Option<String>,
        #[arg(long)] overwrite: bool,
    },
    /// Generate a new inference rule resource file
    InferenceRule {
        #[arg(long)] name:           Option<String>,
        #[arg(long)] scope:          Option<String>,
        #[arg(long)] trigger_events: Vec<String>,
        #[arg(long)] reconciliation: bool,
        #[arg(long)] output:         Option<String>,
        #[arg(long)] overwrite:      bool,
    },
    /// Generate a new event store resource file
    EventStore {
        #[arg(long)] product:  Option<String>,
        #[arg(long)] name:     Option<String>,
        #[arg(long)] output:   Option<String>,
        #[arg(long)] overwrite: bool,
    },
    /// Generate a new config resource file
    Config {
        #[arg(long)] product:  Option<String>,
        #[arg(long)] name:     Option<String>,
        #[arg(long)] output:   Option<String>,
        #[arg(long)] overwrite: bool,
    },
    /// Generate a new product role resource file
    Role {
        #[arg(long)] product:     Option<String>,
        #[arg(long)] name:        Option<String>,
        #[arg(long)] description: Option<String>,
        #[arg(long)] inherits:    Option<String>,
        #[arg(long)] permission:  Vec<String>,
        #[arg(long)] output:      Option<String>,
        #[arg(long)] overwrite:   bool,
    },
    /// Generate a new OAuth scope resource file
    Scope {
        #[arg(long)] product:     Option<String>,
        #[arg(long)] name:        Option<String>,
        #[arg(long)] description: Option<String>,
        #[arg(long)] permission:  Vec<String>,
        #[arg(long)] output:      Option<String>,
        #[arg(long)] overwrite:   bool,
    },
    /// Generate a new M2M permission resource file
    M2mPermission {
        #[arg(long)] product:   Option<String>,
        #[arg(long)] name:      Option<String>,
        #[arg(long)] client:    Option<String>,
        #[arg(long)] scope:     Vec<String>,
        #[arg(long)] output:    Option<String>,
        #[arg(long)] overwrite: bool,
    },
    /// List all available resource types
    List,
}

#[derive(Subcommand)]
enum CompileCommands {
    /// Compile .picloud files to Turtle and validate (offline)
    Validate {
        /// Path to directory containing .picloud and .ttl files
        path: String,
        /// Also validate cross-resource references against live cluster
        #[arg(long)]
        online: bool,
    },
    /// Compile .picloud files to deployment.ttl without submitting
    Build {
        path: String,
        #[arg(long, default_value = "deployment.ttl")]
        output: String,
    },
}

#[derive(Subcommand)]
enum DocsCommands {
    /// Generate documentation from the platform ontology
    Generate {
        /// Output format: markdown, jsonschema, openapi
        #[arg(long, default_value = "markdown")]
        format: String,
        /// Output directory
        #[arg(long, default_value = "docs")]
        output: String,
    },
}

#[derive(Subcommand)]
enum CaCommands {
    /// Export the platform CA certificate for client trust store installation
    Export {
        #[arg(long, default_value = "picloud-ca.pem")]
        output: String,
    },
    /// Install the platform CA into the OS trust store
    Install,
}

#[derive(Subcommand)]
enum SdkCommands {
    /// Generate and publish SDKs from the cluster's live ontology
    Publish {
        /// Languages to publish (rust, typescript, dotnet)
        #[arg(long, num_args = 1.., default_values = ["rust", "typescript", "dotnet"])]
        languages: Vec<String>,
        /// Registry override (defaults to crates.io / npm / NuGet)
        #[arg(long)]
        registry: Option<String>,
    },
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt::init();
    let cli = Cli::parse();

    // TODO: wire command handlers
    // Each command emits an event to https://{domain}/api/commands
    // and subscribes to the result stream via SSE

    println!("PiCloud CLI — domain: {}", cli.domain);
    Ok(())
}
