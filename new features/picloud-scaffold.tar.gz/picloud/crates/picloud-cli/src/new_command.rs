/// `picloud new` command handler
///
/// Generates .picloud resource files from flags or interactive prompts.
/// After writing, runs picloud compile validate automatically.
/// Refuses to overwrite existing files unless --overwrite is specified.
///
/// ADR-050: Builder Pattern CLI for Resource Generation

use picloud_compiler::builder::{BuilderValue, ResourceBuilder};
use picloud_domain::error::{PiCloudError, Result};
use std::path::Path;

/// Options common to all `picloud new` subcommands
pub struct NewOptions {
    pub output:    Option<String>,
    pub overwrite: bool,
}

/// Write a generated .picloud file — checking for overwrite conflicts
pub fn write_resource_file(
    content:   &str,
    resource_type: &str,
    name:      &str,
    opts:      &NewOptions,
) -> Result<String> {
    // Determine output path
    let path = match &opts.output {
        Some(p) => p.clone(),
        None    => default_output_path(resource_type, name),
    };

    // Check if file already exists
    if Path::new(&path).exists() && !opts.overwrite {
        return Err(PiCloudError::ResourceAlreadyExists {
            iri: format!(
                "{} — use --overwrite to replace it",
                path
            ),
        });
    }

    // Create parent directories if needed
    if let Some(parent) = Path::new(&path).parent() {
        std::fs::create_dir_all(parent).map_err(|e| {
            PiCloudError::Internal(format!("Failed to create directory {}: {}", parent.display(), e))
        })?;
    }

    // Write the file
    std::fs::write(&path, content).map_err(|e| {
        PiCloudError::Internal(format!("Failed to write {}: {}", path, e))
    })?;

    Ok(path)
}

/// Default output path when --output is not specified
fn default_output_path(resource_type: &str, name: &str) -> String {
    // Pluralise the resource type for the directory name
    let dir = match resource_type {
        "binary"             => "binaries",
        "inference-rule"     => "inference-rules",
        "event-subscription" => "event-subscriptions",
        other                => &format!("{}s", other),
    };
    format!("./{}/{}.picloud", dir, name)
}

/// Prompt for a required string value if not already provided
pub fn require_string(
    value:       &Option<String>,
    prompt:      &str,
    example:     Option<&str>,
) -> Result<String> {
    if let Some(v) = value {
        return Ok(v.clone());
    }

    // Interactive prompt
    let hint = example
        .map(|e| format!(" (e.g. {})", e))
        .unwrap_or_default();

    print!("? {}{}: ", prompt, hint);
    use std::io::{self, Write, BufRead};
    io::stdout().flush().ok();

    let stdin = io::stdin();
    let line = stdin.lock().lines().next()
        .ok_or_else(|| PiCloudError::Internal("No input provided".into()))?
        .map_err(|e| PiCloudError::Internal(e.to_string()))?;

    let line = line.trim().to_string();
    if line.is_empty() {
        return Err(PiCloudError::ResourceValidationFailed {
            reason: format!("{} is required", prompt),
        });
    }

    Ok(line)
}

/// Prompt for an optional string value
pub fn optional_string(
    value:   &Option<String>,
    prompt:  &str,
    example: Option<&str>,
) -> Option<String> {
    if let Some(v) = value {
        return Some(v.clone());
    }

    let hint = example
        .map(|e| format!(" (e.g. {}, press Enter to skip)", e))
        .unwrap_or_else(|| " (press Enter to skip)".into());

    print!("? {}{}: ", prompt, hint);
    use std::io::{self, Write, BufRead};
    io::stdout().flush().ok();

    let stdin = io::stdin();
    if let Some(Ok(line)) = stdin.lock().lines().next() {
        let line = line.trim().to_string();
        if !line.is_empty() {
            return Some(line);
        }
    }
    None
}

/// Parse "key=value" tag strings into (key, value) pairs
pub fn parse_tags(tags: &[String]) -> Result<Vec<(String, String)>> {
    tags.iter().map(|t| {
        t.split_once('=').map(|(k, v)| (k.to_string(), v.to_string()))
            .ok_or_else(|| PiCloudError::ResourceValidationFailed {
                reason: format!("Tag '{}' must be in key=value format", t),
            })
    }).collect()
}

/// Parse "volume:path" mount strings into (volume, path) pairs
pub fn parse_mounts(mounts: &[String]) -> Result<Vec<(String, String)>> {
    mounts.iter().map(|m| {
        m.split_once(':').map(|(vol, path)| (vol.to_string(), path.to_string()))
            .ok_or_else(|| PiCloudError::ResourceValidationFailed {
                reason: format!("Mount '{}' must be in volume:path format", m),
            })
    }).collect()
}

/// Print success message with file path
pub fn print_generated(path: &str) {
    println!("✓ Generated: {}", path);
}

/// Print validation result
pub fn print_validation(valid: bool, errors: &[picloud_compiler::ValidationError]) {
    if valid {
        println!("✓ Validation passed");
    } else {
        eprintln!("✗ Validation failed:");
        for e in errors {
            eprintln!("  {}", e.message);
        }
    }
}
