/// Identity Types
///
/// PiCloud is a full OIDC provider (ADR-017).
/// Human identities use passkeys/FIDO2 only — no passwords (ADR-025).
/// Workload identities use mTLS certificates injected by the platform.
/// Products act as OIDC App Registrations.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use crate::iri::ResourceIri;

/// A human identity — authenticated via passkey/FIDO2
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HumanIdentity {
    pub id: Uuid,
    pub iri: ResourceIri,
    pub name: String,
    pub email: Option<String>,
    pub passkeys: Vec<RegisteredPasskey>,
    pub platform_roles: Vec<String>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl HumanIdentity {
    /// Enforces ADR-026: admin accounts must have >= 2 passkeys
    pub fn can_remove_passkey(&self, is_admin: bool) -> bool {
        if is_admin {
            self.passkeys.len() > 2
        } else {
            self.passkeys.len() > 1
        }
    }
}

/// A registered WebAuthn/FIDO2 credential bound to a human identity
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RegisteredPasskey {
    pub credential_id: String,
    pub public_key: Vec<u8>,
    pub aaguid: Option<String>,
    pub registered_at: DateTime<Utc>,
    pub last_used_at: Option<DateTime<Utc>>,
    pub display_name: Option<String>,
}

/// A workload identity — mTLS certificate injected at runtime
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkloadIdentity {
    pub id: Uuid,
    pub iri: ResourceIri,
    pub name: String,
    pub product: String,
    pub roles: Vec<String>,
    pub certificate_fingerprint: Option<String>,
    pub created_at: DateTime<Utc>,
}

/// A Product App Registration — OIDC client for applications (ADR-017)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppRegistration {
    pub id: Uuid,
    pub client_id: String,
    /// Hashed — never stored in plaintext
    pub client_secret_hash: String,
    pub product_iri: ResourceIri,
    pub redirect_uris: Vec<String>,
    pub scopes: Vec<String>,
}

/// A bootstrap or re-enrollment token (ADR-026)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EnrollmentToken {
    pub token: String,
    pub purpose: EnrollmentPurpose,
    pub expires_at: DateTime<Utc>,
    pub used: bool,
    /// For admin resets — which identity is being re-enrolled
    pub target_identity: Option<ResourceIri>,
}

impl EnrollmentToken {
    pub fn is_valid(&self) -> bool {
        !self.used && Utc::now() < self.expires_at
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EnrollmentPurpose {
    /// First admin on a fresh cluster
    Bootstrap,
    /// Admin-initiated passkey reset for a user
    PasskeyReset,
    /// Physical recovery — operator ran `picloud cluster recover`
    PhysicalRecovery,
}

/// An RBAC role — additive permissions
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Role {
    pub name: String,
    pub product: Option<String>,
    pub permissions: Vec<Permission>,
}

/// A permission — scoped to a resource IRI pattern and an action
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Permission {
    /// IRI pattern — may include wildcards
    /// e.g. "https://picloud.local/products/photo-app/*"
    pub resource_pattern: String,
    pub action: PermissionAction,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PermissionAction {
    Read,
    Write,
    Delete,
    Execute,
    Query,  // SPARQL query
    Append, // event log append
}

/// A Group — collection of identities sharing roles (ADR-037)
/// Membership is managed automatically by inference rules, never manually
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Group {
    pub id: Uuid,
    pub iri: ResourceIri,
    pub name: String,
    pub description: Option<String>,
    pub roles: Vec<String>,
    pub tags: Vec<Tag>,
    pub created_at: DateTime<Utc>,
}

/// A universal tag — key:value pair attachable to any resource (ADR-036)
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Tag {
    pub key: String,
    pub value: String,
}

impl Tag {
    pub fn new(key: impl Into<String>, value: impl Into<String>) -> Self {
        Self { key: key.into(), value: value.into() }
    }

    /// Parse "team:backend" into Tag { key: "team", value: "backend" }
    pub fn parse(s: &str) -> Option<Self> {
        let (key, value) = s.split_once(':')?;
        Some(Self::new(key.trim(), value.trim()))
    }
}

/// A product-scoped role with permissions and static claims (ADR-051)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductRole {
    pub id:          Uuid,
    pub iri:         ResourceIri,
    pub name:        String,
    pub product:     String,
    pub description: Option<String>,
    /// Parent role IRI — resolved transitively via OWL inference (rdfs:subClassOf)
    pub inherits:    Option<ResourceIri>,
    pub permissions: Vec<String>,
    /// Static key-value claims added to tokens for users with this role
    pub claims:      Vec<StaticClaim>,
}

/// A product-scoped OAuth scope (ADR-051)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductScope {
    pub id:          Uuid,
    pub iri:         ResourceIri,
    pub name:        String,
    pub product:     String,
    pub description: Option<String>,
    pub permissions: Vec<String>,
    /// Static claims added when this scope is granted
    pub claims:      Vec<StaticClaim>,
}

/// A static JWT claim — key-value pair added to tokens (ADR-051)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StaticClaim {
    pub key:   String,
    pub value: String,
}

/// M2M permission — declares which products may request client_credentials
/// tokens against this product (ADR-051)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct M2mPermission {
    pub id:          Uuid,
    pub iri:         ResourceIri,
    /// The product granting access (the resource owner)
    pub product:     String,
    /// The product being granted access (the client)
    pub client:      String,
    pub scopes:      Vec<String>,
    pub description: Option<String>,
}

/// The resolved claims for a token — assembled at issuance time
/// from roles (with inherited permissions), scopes, and custom claims
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResolvedTokenClaims {
    pub subject:     ResourceIri,
    pub audience:    ResourceIri,
    pub issuer:      ResourceIri,
    pub scopes:      Vec<String>,
    pub roles:       Vec<String>,
    /// Full permission set — flattened from all assigned roles (including inherited)
    pub permissions: Vec<String>,
    /// Custom claims — role claims merged with scope claims, role wins on conflict
    pub custom:      std::collections::HashMap<String, String>,
    /// Actor claim — present in on-behalf-of tokens (RFC 8693)
    pub actor:       Option<ResourceIri>,
}

/// Token flow type — determines how the token was issued (ADR-051)
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TokenFlow {
    /// Standard OIDC user authentication
    UserAuth,
    /// RFC 8693 on-behalf-of — user delegated to a product
    OnBehalfOf { actor_product: ResourceIri },
    /// OAuth 2.0 client credentials — M2M
    ClientCredentials { client_product: ResourceIri },
}
