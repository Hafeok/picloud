/// Platform Event Types
///
/// Every state change in PiCloud is an event (ADR-004).
/// Every event carries a schema IRI for versioning (ADR-031).
/// Events are append-only and permanent.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use crate::iri::ResourceIri;

/// The envelope that wraps every event in the platform log.
/// The schema field is the IRI of the JSON Schema / SHACL document
/// describing this event's payload structure.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EventEnvelope {
    pub id: Uuid,
    /// IRI of the schema for this event — permanently dereferenceable
    pub schema: ResourceIri,
    /// Human-readable event type name
    pub event_type: String,
    pub timestamp: DateTime<Utc>,
    /// IRI of the resource that emitted this event
    pub source: ResourceIri,
    /// Product scope — None for platform-level events
    pub product: Option<String>,
    /// Correlation ID linking a command to its result events
    pub correlation_id: Uuid,
    /// Client-supplied idempotency key (ADR-015)
    pub idempotency_key: Option<String>,
    /// Present when this event is being replayed (ADR-035)
    pub replay: Option<ReplayMarker>,
    pub payload: serde_json::Value,
}

/// Marks an event as replayed — allows subscribers to suppress
/// irreversible side effects (emails, payments) while still
/// updating their projections (ADR-035)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayMarker {
    /// Groups all events from a single replay operation
    pub replay_id: Uuid,
    /// When the event was originally written to the log
    pub original_timestamp: DateTime<Utc>,
    /// When the event was re-emitted during this replay
    pub replayed_at: DateTime<Utc>,
}

impl EventEnvelope {
    pub fn new(
        schema: ResourceIri,
        event_type: impl Into<String>,
        source: ResourceIri,
        product: Option<String>,
        correlation_id: Uuid,
        payload: serde_json::Value,
    ) -> Self {
        Self {
            id: Uuid::new_v4(),
            schema,
            event_type: event_type.into(),
            timestamp: Utc::now(),
            source,
            product,
            correlation_id,
            idempotency_key: None,
            replay: None,
            payload,
        }
    }

    pub fn with_idempotency_key(mut self, key: impl Into<String>) -> Self {
        self.idempotency_key = Some(key.into());
        self
    }

    pub fn as_replay(mut self, replay_id: Uuid) -> Self {
        let original_timestamp = self.timestamp;
        self.replay = Some(ReplayMarker {
            replay_id,
            original_timestamp,
            replayed_at: Utc::now(),
        });
        self
    }

    pub fn is_replay(&self) -> bool {
        self.replay.is_some()
    }
}

/// Platform-level event types
/// Each variant corresponds to a schema IRI at:
/// https://picloud.local/schemas/events/{TypeName}/v1
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", content = "data")]
pub enum PlatformEvent {
    // --- Cluster events ---
    NodeJoined(NodeJoinedPayload),
    NodeLeft(NodeLeftPayload),
    NodeJoinRejected(NodeJoinRejectedPayload),
    LeaderElected(LeaderElectedPayload),

    // --- Resource lifecycle events ---
    ResourceDeclared(ResourceDeclaredPayload),
    ResourceProvisioning(ResourceProvisioningPayload),
    ResourceReady(ResourceReadyPayload),
    ResourceFailed(ResourceFailedPayload),
    ResourceDeleted(ResourceDeletedPayload),

    // --- IAM events ---
    IdentityCreated(IdentityCreatedPayload),
    IdentityDeleted(IdentityDeletedPayload),
    PasskeyRegistered(PasskeyRegisteredPayload),
    PasskeyRevoked(PasskeyRevokedPayload),
    TokenIssued(TokenIssuedPayload),

    // --- Product events ---
    ProductDeployed(ProductDeployedPayload),
    ProductUpgradeStarted(ProductUpgradeStartedPayload),
    ProductUpgradeCompleted(ProductUpgradeCompletedPayload),
    ProductUpgradeAborted(ProductUpgradeAbortedPayload),
    ProductDeleted(ProductDeletedPayload),

    // --- Snapshot and backup events (ADR-047) ---
    SnapshotCreated(SnapshotCreatedPayload),
    SnapshotDeleted(SnapshotDeletedPayload),
    SnapshotFailed(SnapshotFailedPayload),
    BackupStarted(BackupStartedPayload),
    BackupCompleted(BackupCompletedPayload),
    BackupFailed(BackupFailedPayload),

    // --- Configuration events (ADR-043) ---
    ConfigChanged(ConfigChangedPayload),

    // --- Feature flag events (ADR-044) ---
    FeatureFlagChanged(FeatureFlagChangedPayload),

    // --- Tag events (ADR-036) ---
    TagAdded(TagAddedPayload),
    TagRemoved(TagRemovedPayload),

    // --- Group events (ADR-037) ---
    GroupCreated(GroupCreatedPayload),
    GroupMembershipChanged(GroupMembershipChangedPayload),

    // --- Inference events (ADR-038) ---
    InferenceRuleEvaluated(InferenceRuleEvaluatedPayload),
    ReconciliationCompleted(ReconciliationCompletedPayload),

    // --- Metric events (ADR-040) ---
    MetricRecorded(MetricRecordedPayload),

    // --- Alert events (ADR-041) ---
    AlertFired(AlertFiredPayload),
    AlertResolved(AlertResolvedPayload),
    ReplayRequested(ReplayRequestedPayload),
    ReplayStarted(ReplayStartedPayload),
    ReplayProgress(ReplayProgressPayload),
    ReplayCompleted(ReplayCompletedPayload),
    ReplayFailed(ReplayFailedPayload),
}

// --- Payload types ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeJoinedPayload {
    pub node_id: Uuid,
    pub node_name: String,
    pub node_iri: ResourceIri,
    pub address: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeJoinRejectedPayload {
    pub node_address: String,
    pub reason: NodeJoinRejectedReason,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NodeJoinRejectedReason {
    InvalidBootstrapToken,
    ClusterIdMismatch,
    CaFingerprintMismatch,
    TokenExpired,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NodeLeftPayload {
    pub node_id: Uuid,
    pub node_iri: ResourceIri,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LeaderElectedPayload {
    pub node_id: Uuid,
    pub node_iri: ResourceIri,
    pub term: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceDeclaredPayload {
    pub resource_iri: ResourceIri,
    pub resource_type: String,
    pub product: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceProvisioningPayload {
    pub resource_iri: ResourceIri,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceReadyPayload {
    pub resource_iri: ResourceIri,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceFailedPayload {
    pub resource_iri: ResourceIri,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceDeletedPayload {
    pub resource_iri: ResourceIri,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityCreatedPayload {
    pub identity_iri: ResourceIri,
    pub identity_type: IdentityType,
    pub name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum IdentityType {
    Human,
    Workload,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityDeletedPayload {
    pub identity_iri: ResourceIri,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PasskeyRegisteredPayload {
    pub identity_iri: ResourceIri,
    pub credential_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PasskeyRevokedPayload {
    pub identity_iri: ResourceIri,
    pub credential_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenIssuedPayload {
    pub identity_iri: ResourceIri,
    pub product: Option<String>,
    pub expires_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductDeployedPayload {
    pub product_iri: ResourceIri,
    pub version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductUpgradeStartedPayload {
    pub product_iri: ResourceIri,
    pub from_version: String,
    pub to_version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductUpgradeCompletedPayload {
    pub product_iri: ResourceIri,
    pub version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductUpgradeAbortedPayload {
    pub product_iri: ResourceIri,
    pub version: String,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProductDeletedPayload {
    pub product_iri: ResourceIri,
}

// --- Replay payload types (ADR-035) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayRequestedPayload {
    pub replay_id: Uuid,
    pub scope: ReplayScope,
    pub from: DateTime<Utc>,
    pub to: Option<DateTime<Utc>>,
    pub requested_by: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayStartedPayload {
    pub replay_id: Uuid,
    pub scope: ReplayScope,
    pub total_events: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayProgressPayload {
    pub replay_id: Uuid,
    pub events_processed: u64,
    pub total_events: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayCompletedPayload {
    pub replay_id: Uuid,
    pub events_processed: u64,
    pub shadow_swapped: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayFailedPayload {
    pub replay_id: Uuid,
    pub events_processed: u64,
    pub reason: String,
}

/// Defines what is being replayed
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ReplayScope {
    /// Full platform event log
    Platform,
    /// All events for a product
    Product { product: String },
    /// A single aggregate stream
    Aggregate {
        product: String,
        store: String,
        aggregate_type: String,
        aggregate_id: Uuid,
    },
    /// A batch of aggregate streams — up to 1000
    AggregateBatch {
        product: String,
        store: String,
        aggregate_type: String,
        aggregate_ids: Vec<Uuid>,
    },
}

// --- Tag payload types (ADR-036) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TagAddedPayload {
    pub resource_iri: ResourceIri,
    pub key: String,
    pub value: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TagRemovedPayload {
    pub resource_iri: ResourceIri,
    pub key: String,
    pub value: String,
}

// --- Group payload types (ADR-037) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GroupCreatedPayload {
    pub group_iri: ResourceIri,
    pub name: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GroupMembershipChangedPayload {
    pub group_iri: ResourceIri,
    pub identity_iri: ResourceIri,
    pub change: MembershipChange,
    pub triggered_by_rule: ResourceIri,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MembershipChange {
    Added,
    Removed,
}

// --- Inference payload types (ADR-038) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InferenceRuleEvaluatedPayload {
    pub rule_iri: ResourceIri,
    pub triggered_by: String,
    pub triples_asserted: u64,
    pub triples_retracted: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReconciliationCompletedPayload {
    pub rules_evaluated: u64,
    pub triples_asserted: u64,
    pub triples_retracted: u64,
    pub duration_ms: u64,
}

// --- Metric payload types (ADR-040) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricRecordedPayload {
    pub node_iri: ResourceIri,
    pub metrics: Vec<Metric>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Metric {
    pub name: String,
    pub value: f64,
    pub unit: String,
}

// --- Alert payload types (ADR-041) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AlertFiredPayload {
    pub alert_type: String,
    pub severity: String,
    pub message: String,
    pub resource_iri: ResourceIri,
    pub rule_iri: ResourceIri,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AlertResolvedPayload {
    pub alert_type: String,
    pub resource_iri: ResourceIri,
    pub rule_iri: ResourceIri,
}

// --- Config payload types (ADR-043) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfigChangedPayload {
    pub product: String,
    pub key: String,
    pub previous_value: Option<String>,
    pub new_value: Option<String>,
    /// None means deleted
    pub change_type: ConfigChangeType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConfigChangeType {
    Created,
    Updated,
    Deleted,
}

// --- Feature flag payload types (ADR-044) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeatureFlagChangedPayload {
    pub product: String,
    pub flag_name: String,
    pub flag_iri: ResourceIri,
    /// Whether the flag is now active for the currently running product version
    pub active: bool,
    pub change_type: FlagChangeType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FlagChangeType {
    /// Flag was created
    Created,
    /// enabled toggled or version expression changed
    Updated,
    /// Flag was deleted
    Deleted,
    /// Product version changed — flag active state changed as a result
    VersionChanged,
}

// --- Snapshot and backup payload types (ADR-047) ---

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotCreatedPayload {
    pub volume_iri:    ResourceIri,
    pub snapshot_name: String,
    pub size_gb:       f64,
    pub nas_path:      String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotDeletedPayload {
    pub volume_iri:    ResourceIri,
    pub snapshot_name: String,
    pub reason:        SnapshotDeleteReason,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SnapshotDeleteReason {
    RetentionPolicy,
    ManualDelete,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotFailedPayload {
    pub volume_iri: ResourceIri,
    pub reason:     String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BackupStartedPayload {
    pub volume_iri:    ResourceIri,
    pub backup_type:   BackupType,
    pub estimated_gb:  Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BackupCompletedPayload {
    pub volume_iri:       ResourceIri,
    pub backup_type:      BackupType,
    pub bytes_uploaded:   u64,
    pub bytes_deduplicated: u64,
    pub duration_seconds: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BackupFailedPayload {
    pub volume_iri:  ResourceIri,
    pub backup_type: BackupType,
    pub reason:      String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BackupType {
    /// Full backup — all chunks
    Full,
    /// Incremental — only changed chunks since last backup
    Incremental,
}

// --- IAM product events (ADR-051) ---

// (Added to PlatformEvent enum below — payload types here)

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoleAssignedPayload {
    pub identity_iri: ResourceIri,
    pub role_iri:     ResourceIri,
    pub product:      String,
    pub assigned_by:  ResourceIri,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoleRevokedPayload {
    pub identity_iri: ResourceIri,
    pub role_iri:     ResourceIri,
    pub product:      String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenExchangedPayload {
    pub subject_iri:   ResourceIri,
    pub actor_iri:     ResourceIri,
    pub target_product: String,
    pub scopes:        Vec<String>,
    pub flow:          String,
}
