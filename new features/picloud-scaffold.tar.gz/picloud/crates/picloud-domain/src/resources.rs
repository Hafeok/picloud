/// Resource Types
///
/// Every platform concept has a typed representation here.
/// These are the nouns of the platform — what can be created,
/// queried, and deleted via the resource API.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use crate::iri::ResourceIri;
use crate::storage::StorageIntent;
use crate::workload::{ContainerSpec, BinarySpec};

/// The lifecycle state of any resource
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ResourceStatus {
    Declared,
    Provisioning,
    Ready,
    Failed,
    Deleting,
}

/// Common metadata carried by every resource
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceMeta {
    pub iri: ResourceIri,
    pub resource_type: String,
    pub name: String,
    pub product: Option<String>,
    pub status: ResourceStatus,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

/// A Product — the top-level deployment unit (ADR-016)
/// Hermetically sealed: owns all its resources, no sharing
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Product {
    pub meta: ResourceMeta,
    pub version: String,
    pub description: Option<String>,
}

/// A Volume — block storage with declared intent (ADR-024)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Volume {
    pub meta: ResourceMeta,
    pub size_gb: u64,
    pub storage_intent: StorageIntent,
    pub volume_type: VolumeType,
    /// Which node currently holds the primary replica
    pub primary_node_id: Option<Uuid>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VolumeType {
    /// Presented as a filesystem path inside the workload
    Mounted,
    /// Presented as a raw block device
    RawBlock,
}

/// A Container workload — OCI image scheduled on the cluster
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Container {
    pub meta: ResourceMeta,
    pub spec: ContainerSpec,
    /// Node the container is currently scheduled on
    pub node_id: Option<Uuid>,
}

/// A Binary workload — raw ARM64 executable
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Binary {
    pub meta: ResourceMeta,
    pub spec: BinarySpec,
    pub node_id: Option<Uuid>,
}

/// A managed Oxigraph RDF store — per-product SPARQL endpoint
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RdfStore {
    pub meta: ResourceMeta,
    pub sparql_endpoint: ResourceIri,
    pub backing_volume: ResourceIri,
}

/// A managed event store — per-product event sourcing (ADR-032)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EventStore {
    pub meta: ResourceMeta,
    pub aggregates: Vec<AggregateDefinition>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AggregateDefinition {
    pub aggregate_type: String,
    /// Path to the .ttl or .shacl schema file, relative to deployment root
    pub schema_file: String,
    /// The IRI where the schema is served once deployed
    pub schema_iri: Option<ResourceIri>,
}

/// An event subscription — inter-product event routing (ADR-022)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EventSubscription {
    pub meta: ResourceMeta,
    /// IRI of the source product
    pub source_product_iri: ResourceIri,
    /// Event type to subscribe to
    pub event_type: String,
    /// Container or binary in this product that receives the event
    pub handler_name: String,
}

/// An ingress — exposes a workload path on the cluster domain
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Ingress {
    pub meta: ResourceMeta,
    pub target_name: String,
    pub port: u16,
    pub path: String,
    pub tls: bool,
}

/// An ontology — .ttl or .shacl file bound to a product version (ADR-023)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Ontology {
    pub meta: ResourceMeta,
    pub file_path: String,
    pub format: OntologyFormat,
    pub served_at: ResourceIri,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OntologyFormat {
    Turtle,
    Shacl,
}

/// A Node — a cluster member
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Node {
    pub meta: ResourceMeta,
    pub node_id: Uuid,
    pub address: String,
    pub is_leader: bool,
    pub storage_capacity_gb: u64,
    pub storage_used_gb: u64,
}

/// An inference rule — SPARQL CONSTRUCT query resource (ADR-038)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InferenceRule {
    pub meta: ResourceMeta,
    pub description: Option<String>,
    /// 'platform' or a product name
    pub scope: String,
    /// Evaluate on matching event types
    pub trigger_events: Vec<String>,
    /// Also run on 10-minute reconciliation schedule
    pub reconciliation: bool,
    /// SPARQL CONSTRUCT query body
    pub construct: String,
}

/// An alert triple produced by an inference rule (ADR-041)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Alert {
    pub alert_type: String,
    pub severity: AlertSeverity,
    pub message: String,
    pub resource_iri: ResourceIri,
    pub rule_iri: ResourceIri,
    pub fired_at: chrono::DateTime<chrono::Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AlertSeverity {
    Info,
    Warning,
    Critical,
}

/// A configuration store entry (ADR-043)
/// Tags are queryable via SPARQL across the product graph
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConfigEntry {
    pub meta: ResourceMeta,
    pub key: String,
    pub value: String,
    pub value_type: ConfigValueType,
    pub tags: Vec<crate::identity::Tag>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConfigValueType {
    String,
    Int,
    Float,
    Bool,
    Json, // future
}

/// The effective config for a workload — product config merged with workload overrides.
/// Workload values win on collision (ADR-043).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EffectiveConfig {
    pub workload_iri: ResourceIri,
    pub entries: Vec<ConfigEntry>,
}

/// A feature flag — version-bound, on/off (ADR-044)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FeatureFlag {
    pub meta: ResourceMeta,
    pub name: String,
    pub description: Option<String>,
    pub enabled: bool,
    pub version_expr: VersionExpression,
}

/// Version expression for feature flag targeting (ADR-044)
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum VersionExpression {
    /// = N
    Exact(u32),
    /// > N
    GreaterThan(u32),
    /// >= N
    GreaterThanOrEqual(u32),
    /// < N
    LessThan(u32),
    /// <= N
    LessThanOrEqual(u32),
    /// N..M inclusive
    Range { from: u32, to: u32 },
}

impl VersionExpression {
    /// Evaluate whether a major version satisfies this expression
    pub fn matches(&self, major: u32) -> bool {
        match self {
            Self::Exact(n)              => major == *n,
            Self::GreaterThan(n)        => major > *n,
            Self::GreaterThanOrEqual(n) => major >= *n,
            Self::LessThan(n)           => major < *n,
            Self::LessThanOrEqual(n)    => major <= *n,
            Self::Range { from, to }    => major >= *from && major <= *to,
        }
    }

    /// Parse a version expression string — validated at deploy time
    pub fn parse(s: &str) -> Option<Self> {
        let s = s.trim();
        if let Some(rest) = s.strip_prefix("= ")  { return rest.parse().ok().map(Self::Exact) }
        if let Some(rest) = s.strip_prefix(">= ") { return rest.parse().ok().map(Self::GreaterThanOrEqual) }
        if let Some(rest) = s.strip_prefix("> ")  { return rest.parse().ok().map(Self::GreaterThan) }
        if let Some(rest) = s.strip_prefix("<= ") { return rest.parse().ok().map(Self::LessThanOrEqual) }
        if let Some(rest) = s.strip_prefix("< ")  { return rest.parse().ok().map(Self::LessThan) }
        if let Some((from, to)) = s.split_once("..") {
            let from = from.trim().parse().ok()?;
            let to   = to.trim().parse().ok()?;
            return Some(Self::Range { from, to });
        }
        None
    }
}

/// Evaluated flag result returned to workloads (ADR-044)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlagEvaluation {
    pub name: String,
    pub active: bool,
    pub version_expr: String,
}

/// An OTel export configuration — forwards raw OTel to an external collector (ADR-045)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OtelExport {
    pub meta:     ResourceMeta,
    pub endpoint: String,
    pub protocol: OtelProtocol,
    pub signals:  Vec<OtelSignal>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OtelProtocol {
    Grpc,
    Http,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OtelSignal {
    Traces,
    Metrics,
    Logs,
}

/// Telemetry retention policy — per signal type (ADR-046)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryRetention {
    pub traces_days:  u32,   // default: 7
    pub metrics_days: u32,   // default: 30
    pub logs_days:    u32,   // default: 7
}

impl Default for TelemetryRetention {
    fn default() -> Self {
        Self {
            traces_days:  7,
            metrics_days: 30,
            logs_days:    7,
        }
    }
}

/// A product-scoped role resource (ADR-051)
pub use crate::identity::{ProductRole, ProductScope, M2mPermission};
