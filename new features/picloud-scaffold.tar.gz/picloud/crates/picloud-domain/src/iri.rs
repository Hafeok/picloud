/// IRI Model
///
/// Every resource in PiCloud has a canonical IRI that is both its unique
/// identifier and its network location (ADR-029).
///
/// Scheme: https://{cluster_domain}/products/{product}/{type}/{name}
///
/// Examples:
///   https://picloud.local/products/photo-app/containers/api-server
///   https://picloud.local/products/photo-app/graph
///   https://picloud.local/products/photo-app/ontology
///   https://picloud.local/nodes/pi-node-01
///   https://picloud.local/schemas/events/ResourceReady/v1

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use std::fmt;
use url::Url;
use crate::error::{PiCloudError, Result};

/// The cluster domain — configurable at init, defaults to picloud.local (ADR-042)
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ClusterDomain(pub String);

impl Default for ClusterDomain {
    fn default() -> Self {
        Self("picloud.local".to_string())
    }
}

/// The dual identity of a PiCloud cluster — established at cluster init,
/// never changes for the lifetime of the cluster (ADR-042)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClusterIdentity {
    /// Cryptographic cluster boundary — UUID generated at cluster init
    pub cluster_id: uuid::Uuid,
    /// Human-readable tenant identity — root of all IRIs
    pub domain: ClusterDomain,
    /// When this cluster was initialised
    pub created_at: DateTime<Utc>,
    /// SHA-256 fingerprint of the cluster CA certificate
    /// All node certificates must chain to this CA
    pub ca_fingerprint: String,
}

impl ClusterIdentity {
    pub fn new(domain: ClusterDomain, ca_fingerprint: String) -> Self {
        Self {
            cluster_id: uuid::Uuid::new_v4(),
            domain,
            created_at: Utc::now(),
            ca_fingerprint,
        }
    }
}

/// A fully-qualified, dereferenceable IRI for a platform resource.
/// IRIs are stable — they do not change when workloads reschedule.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct ResourceIri(pub String);

impl ResourceIri {
    pub fn new(s: impl Into<String>) -> Result<Self> {
        let s = s.into();
        // Validate it parses as a URL
        Url::parse(&s).map_err(|_| PiCloudError::InvalidIri { iri: s.clone() })?;
        Ok(Self(s))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for ResourceIri {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

/// Constructs canonical IRIs for all resource types
pub struct IriBuilder {
    domain: ClusterDomain,
}

impl IriBuilder {
    pub fn new(domain: ClusterDomain) -> Self {
        Self { domain }
    }

    pub fn cluster_root(&self) -> ResourceIri {
        ResourceIri(format!("https://{}/", self.domain.0))
    }

    pub fn node(&self, node_name: &str) -> ResourceIri {
        ResourceIri(format!("https://{}/nodes/{}", self.domain.0, node_name))
    }

    pub fn product(&self, product_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}",
            self.domain.0, product_name
        ))
    }

    pub fn resource(
        &self,
        product_name: &str,
        resource_type: &str,
        resource_name: &str,
    ) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/{}/{}",
            self.domain.0, product_name, resource_type, resource_name
        ))
    }

    pub fn product_graph(&self, product_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/graph",
            self.domain.0, product_name
        ))
    }

    pub fn product_ontology(&self, product_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/ontology",
            self.domain.0, product_name
        ))
    }

    pub fn product_events(&self, product_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/events",
            self.domain.0, product_name
        ))
    }

    pub fn event_schema(&self, event_type: &str, version: u32) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/schemas/events/{}/v{}",
            self.domain.0, event_type, version
        ))
    }

    pub fn aggregate_stream(
        &self,
        product_name: &str,
        store_name: &str,
        aggregate_type: &str,
        aggregate_id: &str,
    ) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/event-store/{}/{}/{}/events",
            self.domain.0, product_name, store_name, aggregate_type, aggregate_id
        ))
    }

    pub fn product_config(&self, product_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/config",
            self.domain.0, product_name
        ))
    }

    pub fn config_entry(&self, product_name: &str, key: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/config/{}",
            self.domain.0, product_name, key
        ))
    }

    pub fn workload_config(&self, product_name: &str, resource_type: &str, resource_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/{}/{}/config",
            self.domain.0, product_name, resource_type, resource_name
        ))
    }

    pub fn product_flags(&self, product_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/flags",
            self.domain.0, product_name
        ))
    }

    pub fn feature_flag(&self, product_name: &str, flag_name: &str) -> ResourceIri {
        ResourceIri(format!(
            "https://{}/products/{}/flags/{}",
            self.domain.0, product_name, flag_name
        ))
    }
}
