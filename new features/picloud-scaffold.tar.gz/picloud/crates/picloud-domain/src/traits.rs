/// Domain Traits
///
/// These are the abstractions that slices implement.
/// Slices depend only on these traits, never on each other's concrete types.
/// The composition root (picloud binary) wires implementations together.
///
/// This is how vertical slice architecture is enforced at the type level.

use async_trait::async_trait;
use uuid::Uuid;
use crate::error::Result;
use crate::events::EventEnvelope;
use crate::iri::ResourceIri;

// ---- Event Log ----

/// Append events to the Raft-replicated log and subscribe to the stream.
/// Implemented by: picloud-events
#[async_trait]
pub trait EventLog: Send + Sync {
    /// Append an event. Idempotent via idempotency_key.
    async fn append(&self, event: EventEnvelope) -> Result<()>;

    /// Subscribe to all events — returns a stream channel receiver.
    /// Filter by correlation_id to track a specific command.
    async fn subscribe(
        &self,
        filter: EventFilter,
    ) -> Result<tokio::sync::broadcast::Receiver<EventEnvelope>>;
}

#[derive(Debug, Clone, Default)]
pub struct EventFilter {
    pub correlation_id: Option<Uuid>,
    pub product: Option<String>,
    pub event_types: Vec<String>,
}

// ---- State Projection ----

/// Projects events into the RDF graph read model.
/// Implemented by: picloud-rdf
#[async_trait]
pub trait StateProjector: Send + Sync {
    /// Process a single event and update the graph
    async fn project(&self, event: &EventEnvelope) -> Result<()>;

    /// Execute a SPARQL query against the cluster graph
    async fn query(&self, sparql: &str) -> Result<QueryResult>;

    /// Execute a SPARQL query against a product's named graph
    async fn query_product(&self, product_iri: &ResourceIri, sparql: &str)
        -> Result<QueryResult>;
}

#[derive(Debug, Clone)]
pub struct QueryResult {
    pub bindings: Vec<serde_json::Value>,
}

// ---- Identity ----

/// Issue and validate identity tokens. Manage passkeys and workload certs.
/// Implemented by: picloud-iam
#[async_trait]
pub trait IdentityProvider: Send + Sync {
    async fn issue_token(
        &self,
        identity_iri: &ResourceIri,
        product: Option<&str>,
    ) -> Result<String>;

    async fn validate_token(&self, token: &str) -> Result<ValidatedIdentity>;

    async fn issue_workload_certificate(
        &self,
        workload_iri: &ResourceIri,
    ) -> Result<WorkloadCertificate>;
}

#[derive(Debug, Clone)]
pub struct ValidatedIdentity {
    pub identity_iri: ResourceIri,
    pub product: Option<String>,
    pub roles: Vec<String>,
}

#[derive(Debug, Clone)]
pub struct WorkloadCertificate {
    pub certificate_pem: String,
    pub private_key_pem: String,
    pub expires_at: chrono::DateTime<chrono::Utc>,
}

// ---- Storage ----

/// Allocate and manage block volumes across the cluster.
/// Implemented by: picloud-storage
#[async_trait]
pub trait StorageBackend: Send + Sync {
    async fn allocate_volume(
        &self,
        volume_iri: &ResourceIri,
        size_gb: u64,
        intent: &crate::storage::StorageIntent,
    ) -> Result<VolumeHandle>;

    async fn delete_volume(&self, volume_iri: &ResourceIri) -> Result<()>;

    async fn available_capacity_gb(&self) -> Result<u64>;
}

#[derive(Debug, Clone)]
pub struct VolumeHandle {
    pub volume_iri: ResourceIri,
    pub device_path: String,
    pub replicated_to: Vec<Uuid>,
}

// ---- Workload Scheduler ----

/// Schedule and manage container and binary workloads.
/// Implemented by: picloud-workload
#[async_trait]
pub trait WorkloadScheduler: Send + Sync {
    async fn schedule(
        &self,
        workload_iri: &ResourceIri,
        spec: &WorkloadSpec,
    ) -> Result<WorkloadHandle>;

    async fn stop(&self, workload_iri: &ResourceIri) -> Result<()>;

    async fn status(&self, workload_iri: &ResourceIri) -> Result<WorkloadStatus>;
}

#[derive(Debug, Clone)]
pub enum WorkloadSpec {
    Container(crate::workload::ContainerSpec),
    Binary(crate::workload::BinarySpec),
}

#[derive(Debug, Clone)]
pub struct WorkloadHandle {
    pub workload_iri: ResourceIri,
    pub node_id: Uuid,
    pub pid: Option<u32>,
}

#[derive(Debug, Clone)]
pub enum WorkloadStatus {
    Running,
    Stopped,
    Failed { reason: String },
    Unknown,
}

// ---- Cluster ----

/// Cluster membership and node management.
/// Implemented by: picloud-cluster
#[async_trait]
pub trait ClusterMembership: Send + Sync {
    async fn is_leader(&self) -> bool;
    async fn leader_id(&self) -> Result<Uuid>;
    async fn members(&self) -> Result<Vec<NodeInfo>>;
    async fn local_node_id(&self) -> Uuid;
}

#[derive(Debug, Clone)]
pub struct NodeInfo {
    pub node_id: Uuid,
    pub node_iri: ResourceIri,
    pub address: String,
    pub is_leader: bool,
}

// ---- DNS ----

/// Register and resolve internal DNS names.
/// Implemented by: picloud-network
#[async_trait]
pub trait DnsRegistry: Send + Sync {
    async fn register(&self, iri: &ResourceIri, address: &str) -> Result<()>;
    async fn deregister(&self, iri: &ResourceIri) -> Result<()>;
    async fn resolve(&self, iri: &ResourceIri) -> Result<String>;
}

// ---- Replay Engine ----

/// Replay events from the log through current projectors,
/// re-emit to subscribers with replay marker, swap shadow graph atomically.
/// Implemented by: picloud-events + picloud-rdf (coordinated in composition root)
#[async_trait]
pub trait ReplayEngine: Send + Sync {
    /// Start a replay operation — returns a replay_id
    /// The replay builds a shadow projection and swaps atomically on completion
    async fn start_replay(
        &self,
        scope: crate::events::ReplayScope,
        from: chrono::DateTime<chrono::Utc>,
        to: Option<chrono::DateTime<chrono::Utc>>,
    ) -> Result<uuid::Uuid>;

    /// Get the current status of a replay operation
    async fn replay_status(
        &self,
        replay_id: uuid::Uuid,
    ) -> Result<ReplayStatus>;

    /// Cancel an in-progress replay — live graph unchanged
    async fn cancel_replay(&self, replay_id: uuid::Uuid) -> Result<()>;
}

#[derive(Debug, Clone)]
pub enum ReplayStatus {
    Pending,
    Running {
        events_processed: u64,
        total_events: Option<u64>,
    },
    Completed {
        events_processed: u64,
    },
    Failed {
        reason: String,
    },
    Cancelled,
}

// ---- Inference Engine ----

/// Evaluates SPARQL CONSTRUCT rules against the RDF graph,
/// asserts/retracts produced triples, emits derived events.
/// Implemented by: picloud-rdf
#[async_trait]
pub trait InferenceEngine: Send + Sync {
    /// Evaluate all rules triggered by a given event type
    async fn evaluate_for_event(&self, event_type: &str) -> Result<InferenceResult>;

    /// Run the full reconciliation pass — all rules with reconciliation: true
    async fn reconcile(&self) -> Result<InferenceResult>;
}

#[derive(Debug, Clone, Default)]
pub struct InferenceResult {
    pub rules_evaluated: u64,
    pub triples_asserted: u64,
    pub triples_retracted: u64,
}

// ---- Metrics Agent ----

/// Collects hardware metrics and emits MetricRecorded events.
/// Implemented by: picloud-cluster (runs on every node)
#[async_trait]
pub trait MetricsAgent: Send + Sync {
    /// Sample current hardware metrics and emit MetricRecorded event
    async fn sample_and_emit(&self) -> Result<()>;

    /// Get the configured sample interval
    fn sample_interval_seconds(&self) -> u64;
}

// ---- OTel Event Stream ----

/// High-throughput in-process pub/sub for OTel signals.
/// Not Raft-replicated — bounded buffer, drop-on-overflow.
/// Implemented by: picloud-http (OTLP receiver) + picloud-events (stream)
#[async_trait]
pub trait OtelStream: Send + Sync {
    /// Publish a batch of OTel spans
    async fn publish_traces(&self, batch: Vec<serde_json::Value>) -> Result<()>;
    /// Publish a batch of OTel metrics
    async fn publish_metrics(&self, batch: Vec<serde_json::Value>) -> Result<()>;
    /// Publish a batch of OTel log records
    async fn publish_logs(&self, batch: Vec<serde_json::Value>) -> Result<()>;
    /// Subscribe to the OTel stream
    async fn subscribe(&self) -> Result<tokio::sync::broadcast::Receiver<OtelBatch>>;
}

#[derive(Debug, Clone)]
pub enum OtelBatch {
    Traces(Vec<serde_json::Value>),
    Metrics(Vec<serde_json::Value>),
    Logs(Vec<serde_json::Value>),
}

// ---- Telemetry Store ----

/// Writes OTel data to Parquet files and queries via DataFusion (ADR-046).
/// Implemented by: picloud-storage
#[async_trait]
pub trait TelemetryStore: Send + Sync {
    /// Write a batch of spans to the trace Parquet store
    async fn write_traces(&self, batch: Vec<serde_json::Value>) -> Result<()>;
    /// Write a batch of metric points
    async fn write_metrics(&self, batch: Vec<serde_json::Value>) -> Result<()>;
    /// Write a batch of log records
    async fn write_logs(&self, batch: Vec<serde_json::Value>) -> Result<()>;
    /// Execute a SQL query over the telemetry Parquet files via DataFusion
    async fn query(&self, signal: TelemetrySignal, sql: &str) -> Result<QueryResult>;
    /// Run retention cleanup — delete partitions older than policy
    async fn apply_retention(&self, policy: &crate::resources::TelemetryRetention) -> Result<()>;
}

#[derive(Debug, Clone)]
pub enum TelemetrySignal {
    Traces,
    Metrics,
    Logs,
}
