/// Storage Types
///
/// Products declare storage intent — not implementation (ADR-024).
/// The platform translates intent into block allocation and replication.
/// MVP ships full-replication only.

use serde::{Deserialize, Serialize};

/// What a Product needs from storage — declared in the resource file.
/// The platform decides how to satisfy this intent.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageIntent {
    pub durability:  DurabilityTier,
    pub performance: PerformanceTier,
    /// Point-in-time snapshots stored on a local NAS (ADR-047)
    pub snapshots: Option<SnapshotConfig>,
    /// Offsite backup to an S3-compatible endpoint (ADR-047)
    pub offsite: Option<OffsiteBackupConfig>,
}

impl Default for StorageIntent {
    fn default() -> Self {
        Self {
            durability:  DurabilityTier::FullReplication,
            performance: PerformanceTier::Standard,
            snapshots:   None,
            offsite:     None,
        }
    }
}

/// Snapshot configuration — point-in-time copies on a local NAS
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotConfig {
    pub enabled:   bool,
    pub schedule:  SnapshotSchedule,
    /// Secret name containing NAS connection details (NFS/SMB)
    pub storage_secret: String,
    pub retention: SnapshotRetention,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SnapshotSchedule {
    Hourly,
    Daily,
    Weekly,
}

/// How many snapshots to keep per category.
/// 0 means keep forever.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SnapshotRetention {
    pub daily:   u32,
    pub weekly:  u32,
    pub monthly: u32,
}

/// Offsite backup configuration — S3-compatible endpoint
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OffsiteBackupConfig {
    pub enabled:           bool,
    /// Secret name containing S3 connection details
    pub target_secret:     String,
    pub frequency:         BackupFrequency,
    /// Always encrypt before upload — platform manages the key
    pub encryption:        bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BackupFrequency {
    Daily,
    Weekly,
}

/// How many nodes hold a copy of this data
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum DurabilityTier {
    /// Replicated to every available node — maximum durability
    /// This is the only tier available in Phase 1 (MVP)
    FullReplication,

    // --- Phase 4 tiers ---
    /// Replicated to a majority of nodes
    Quorum,
    /// Single node — no replication. Use for cache or ephemeral data.
    Local,
    /// No persistence — lost on workload restart
    None,
}

/// Read/write performance characteristics
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PerformanceTier {
    /// Balanced read/write — default
    Standard,

    // --- Phase 4 tiers ---
    /// Optimised for low-latency random read/write (databases)
    Fast,
    /// Optimised for sequential write, infrequent read
    Archive,
}
