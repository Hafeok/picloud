/// IRI Space HTTP Server
///
/// Serves every platform resource at its canonical IRI (ADR-029).
/// HTTP content negotiation returns different representations:
///
///   Accept: text/turtle          → Turtle RDF
///   Accept: application/ld+json  → JSON-LD
///   Accept: application/json     → Plain JSON
///   Accept: text/html            → Human-readable (future portal)
///
/// The cluster root (https://picloud.local/) returns a description
/// of all Products — the semantic service registry.

use picloud_domain::error::Result;

/// Supported content types for RDF resources
#[derive(Debug, Clone, PartialEq)]
pub enum ContentType {
    Turtle,
    JsonLd,
    Json,
    Html,
}

impl ContentType {
    /// Parse from Accept header value
    pub fn from_accept(accept: &str) -> Self {
        if accept.contains("text/turtle") {
            return Self::Turtle;
        }
        if accept.contains("application/ld+json") {
            return Self::JsonLd;
        }
        if accept.contains("text/html") {
            return Self::Html;
        }
        Self::Json
    }

    pub fn mime_type(&self) -> &'static str {
        match self {
            Self::Turtle => "text/turtle; charset=utf-8",
            Self::JsonLd => "application/ld+json; charset=utf-8",
            Self::Json   => "application/json; charset=utf-8",
            Self::Html   => "text/html; charset=utf-8",
        }
    }
}

/// Route an incoming request against the platform IRI space.
/// Returns the resource type so the handler can query Oxigraph.
pub fn route_iri(path: &str) -> IriRoute {
    let segments: Vec<&str> = path.trim_start_matches('/').split('/').collect();

    match segments.as_slice() {
        // Cluster root — semantic service registry
        [] | [""] => IriRoute::ClusterRoot,

        // Node resource
        ["nodes", node_name] => IriRoute::Node { name: node_name.to_string() },

        // Product root
        ["products", product] => IriRoute::Product { name: product.to_string() },

        // Product SPARQL endpoint
        ["products", product, "graph"] => IriRoute::ProductGraph { product: product.to_string() },

        // Product ontology
        ["products", product, "ontology"] => IriRoute::ProductOntology { product: product.to_string() },

        // Product event stream (SSE)
        ["products", product, "events"] => IriRoute::ProductEvents { product: product.to_string() },

        // Product config
        ["products", product, "config"] => IriRoute::ProductConfig { product: product.to_string() },
        ["products", product, "config", key] => IriRoute::ConfigEntry {
            product: product.to_string(),
            key:     key.to_string(),
        },

        // Feature flags
        ["products", product, "flags"] => IriRoute::ProductFlags { product: product.to_string() },
        ["products", product, "flags", flag] => IriRoute::FeatureFlag {
            product: product.to_string(),
            flag:    flag.to_string(),
        },

        // Event store aggregate stream
        ["products", product, "event-store", store, agg_type, agg_id, "events"] => {
            IriRoute::AggregateStream {
                product:        product.to_string(),
                store:          store.to_string(),
                aggregate_type: agg_type.to_string(),
                aggregate_id:   agg_id.to_string(),
            }
        }

        // Schema registry
        ["schemas", "events", event_type, version] => IriRoute::EventSchema {
            event_type: event_type.to_string(),
            version:    version.to_string(),
        },

        // OTLP endpoint
        ["otel"] => IriRoute::OtlpEndpoint,

        // Generic resource
        ["products", product, resource_type, resource_name] => IriRoute::Resource {
            product:       product.to_string(),
            resource_type: resource_type.to_string(),
            name:          resource_name.to_string(),
        },

        _ => IriRoute::NotFound,
    }
}

/// The resolved route for an incoming IRI request
#[derive(Debug, Clone)]
pub enum IriRoute {
    ClusterRoot,
    Node           { name: String },
    Product        { name: String },
    ProductGraph   { product: String },
    ProductOntology{ product: String },
    ProductEvents  { product: String },
    ProductConfig  { product: String },
    ConfigEntry    { product: String, key: String },
    ProductFlags   { product: String },
    FeatureFlag    { product: String, flag: String },
    AggregateStream{ product: String, store: String, aggregate_type: String, aggregate_id: String },
    EventSchema    { event_type: String, version: String },
    OtlpEndpoint,
    Resource       { product: String, resource_type: String, name: String },
    NotFound,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn routes_cluster_root() {
        assert!(matches!(route_iri("/"), IriRoute::ClusterRoot));
        assert!(matches!(route_iri(""),  IriRoute::ClusterRoot));
    }

    #[test]
    fn routes_product() {
        assert!(matches!(
            route_iri("/products/photo-app"),
            IriRoute::Product { name } if name == "photo-app"
        ));
    }

    #[test]
    fn routes_product_graph() {
        assert!(matches!(
            route_iri("/products/photo-app/graph"),
            IriRoute::ProductGraph { product } if product == "photo-app"
        ));
    }

    #[test]
    fn routes_feature_flag() {
        assert!(matches!(
            route_iri("/products/photo-app/flags/new-upload-flow"),
            IriRoute::FeatureFlag { product, flag }
            if product == "photo-app" && flag == "new-upload-flow"
        ));
    }

    #[test]
    fn content_negotiation() {
        assert_eq!(ContentType::from_accept("text/turtle"),         ContentType::Turtle);
        assert_eq!(ContentType::from_accept("application/ld+json"), ContentType::JsonLd);
        assert_eq!(ContentType::from_accept("application/json"),    ContentType::Json);
        assert_eq!(ContentType::from_accept("*/*"),                 ContentType::Json);
    }
}
