/// Reverse Proxy
///
/// Forwards incoming HTTP requests to upstream containers using hyper.
/// Streams responses back to the client.
/// Attaches OTel trace context to upstream requests (ADR-045).
/// Returns 503 with Retry-After when upstream is unreachable.

use std::time::Duration;
use picloud_domain::error::{PiCloudError, Result};
use crate::router::Upstream;

/// Forward a request to an upstream container.
/// Called after route lookup — upstream address is already resolved.
///
/// Phase 1: basic HTTP/1.1 proxying
/// Phase 2: WebSocket upgrade, HTTP/2
pub async fn forward(
    upstream: &Upstream,
    method: http_method::Method,
    path: &str,
    headers: HeaderMap,
    body: Bytes,
    trace_context: Option<TraceContext>,
) -> Result<ProxyResponse> {
    let url = format!("http://{}:{}{}", upstream.node_address, upstream.port, path);

    // TODO: implement with hyper client
    // Key steps:
    // 1. Build hyper request from incoming request
    // 2. Inject W3C trace context headers (ADR-045)
    // 3. Forward to upstream with timeout
    // 4. Stream response back
    // 5. On connection refused → return 503 with Retry-After: 5

    tracing::debug!(url = %url, "Proxying request to upstream");

    Err(PiCloudError::Internal("proxy not yet implemented".into()))
}

/// Proxy response — status, headers, and streamed body
pub struct ProxyResponse {
    pub status:  u16,
    pub headers: std::collections::HashMap<String, String>,
    pub body:    Vec<u8>,
}

/// W3C trace context for correlation (ADR-045)
pub struct TraceContext {
    pub traceparent: String,
    pub tracestate:  Option<String>,
}

// Type stubs until hyper types are wired in
type HeaderMap = std::collections::HashMap<String, String>;
type Bytes     = Vec<u8>;
mod http_method {
    pub struct Method(pub String);
}

/// Timeout for upstream connections — fail fast rather than queue
pub const UPSTREAM_CONNECT_TIMEOUT: Duration = Duration::from_secs(5);
pub const UPSTREAM_REQUEST_TIMEOUT: Duration = Duration::from_secs(60);
/// How long clients should wait before retrying after a 503
pub const RETRY_AFTER_SECONDS: u32 = 5;
