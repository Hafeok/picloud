/// Ingress Router
///
/// Maintains an in-memory routing table rebuilt from the RDF graph
/// on every IngressCreated, IngressUpdated, IngressDeleted, and
/// WorkloadRescheduled event.
///
/// Lookups are O(1) by hostname, O(n) path prefix match within a host
/// (n = number of routes per host, typically very small).
///
/// No config files. No process restarts. The routing table IS the RDF graph.

use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use picloud_domain::iri::ResourceIri;

/// The complete router state — shared across the HTTP server threads
pub type SharedRouter = Arc<RwLock<IngressRouter>>;

pub struct IngressRouter {
    /// External routes — TLS terminated, publicly reachable on port 443
    /// Keyed by hostname (e.g. "photos.picloud.local")
    external: HashMap<String, Vec<RouteEntry>>,
    /// Internal routes — mTLS mesh only, never externally reachable
    /// Used for metrics, health checks, debug ports
    internal: Vec<RouteEntry>,
}

#[derive(Debug, Clone)]
pub struct RouteEntry {
    /// Path prefix to match (e.g. "/api", "/"). Longest prefix wins.
    pub path_prefix:  String,
    pub upstream:     Upstream,
    pub product:      String,
    pub workload_iri: ResourceIri,
    pub ingress_iri:  ResourceIri,
}

#[derive(Debug, Clone)]
pub struct Upstream {
    /// Internal cluster address of the node running this workload
    pub node_address: String,
    pub port:         u16,
}

impl IngressRouter {
    pub fn new() -> Self {
        Self {
            external: HashMap::new(),
            internal: Vec::new(),
        }
    }

    /// Look up a route for an external request.
    /// Returns the best matching route (longest path prefix wins).
    pub fn lookup_external(&self, hostname: &str, path: &str) -> Option<&RouteEntry> {
        let routes = self.external.get(hostname)?;
        routes
            .iter()
            .filter(|r| path.starts_with(&r.path_prefix))
            .max_by_key(|r| r.path_prefix.len())
    }

    /// Look up a route for an internal mesh request by workload IRI and port
    pub fn lookup_internal(&self, workload_iri: &ResourceIri, port: u16) -> Option<&RouteEntry> {
        self.internal
            .iter()
            .find(|r| &r.workload_iri == workload_iri && r.upstream.port == port)
    }

    /// Add or update a route — called on IngressCreated / IngressUpdated events
    pub fn upsert(&mut self, entry: RouteEntry, internal: bool) {
        if internal {
            self.remove_internal(&entry.ingress_iri);
            self.internal.push(entry);
        } else {
            // TODO: extract hostname from entry — passed via ingress resource
            // For now, stored with the platform domain
            let host = entry.workload_iri.as_str()
                .split('/')
                .nth(2)
                .unwrap_or("picloud.local")
                .to_string();
            let routes = self.external.entry(host).or_default();
            routes.retain(|r| r.ingress_iri != entry.ingress_iri);
            routes.push(entry);
        }
    }

    /// Remove a route — called on IngressDeleted events
    pub fn remove(&mut self, ingress_iri: &ResourceIri) {
        for routes in self.external.values_mut() {
            routes.retain(|r| &r.ingress_iri != ingress_iri);
        }
        self.remove_internal(ingress_iri);
    }

    /// Update the upstream address when a workload reschedules to a new node
    pub fn update_upstream(&mut self, workload_iri: &ResourceIri, new_address: String) {
        for routes in self.external.values_mut() {
            for route in routes.iter_mut() {
                if &route.workload_iri == workload_iri {
                    route.upstream.node_address = new_address.clone();
                }
            }
        }
        for route in self.internal.iter_mut() {
            if &route.workload_iri == workload_iri {
                route.upstream.node_address = new_address.clone();
            }
        }
    }

    fn remove_internal(&mut self, ingress_iri: &ResourceIri) {
        self.internal.retain(|r| &r.ingress_iri != ingress_iri);
    }

    pub fn route_count(&self) -> usize {
        self.external.values().map(|v| v.len()).sum::<usize>() + self.internal.len()
    }
}

impl Default for IngressRouter {
    fn default() -> Self {
        Self::new()
    }
}
