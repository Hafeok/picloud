//! picloud-http
//!
//! HTTP server, IRI routing, content negotiation, and native ingress router.
//! Depends only on picloud-domain — no other slice imports.
//!
//! Modules:
//!   router  — in-memory routing table, rebuilt from RDF graph on ingress events
//!   proxy   — hyper-based reverse proxy, streams requests to upstream containers
//!   tls     — SNI-based certificate selection, rustls server config
//!   ingress — event subscription handler, keeps router in sync with platform state
//!   iri     — IRI space HTTP server, content negotiation (text/turtle, application/ld+json)

pub mod router;
pub mod proxy;
pub mod tls;
pub mod ingress;
pub mod iri;
