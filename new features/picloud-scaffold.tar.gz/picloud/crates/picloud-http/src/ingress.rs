/// Ingress Event Handler
///
/// Subscribes to the platform event stream and keeps the router
/// and TLS state in sync with ingress resource changes.
///
/// This is the bridge between the event log (source of truth)
/// and the in-memory router (operational state).
///
/// Events handled:
///   IngressCreated       → upsert route, issue TLS cert
///   IngressUpdated       → upsert route, refresh TLS cert if hostname changed
///   IngressDeleted       → remove route, remove TLS cert
///   WorkloadRescheduled  → update upstream address for all affected routes
///   WorkloadFailed       → mark upstream unhealthy (return 503 to clients)

use picloud_domain::error::Result;
use crate::router::{RouteEntry, SharedRouter, Upstream};
use crate::tls::SharedTls;

pub struct IngressEventHandler {
    router: SharedRouter,
    tls:    SharedTls,
}

impl IngressEventHandler {
    pub fn new(router: SharedRouter, tls: SharedTls) -> Self {
        Self { router, tls }
    }

    /// Handle a platform event that affects ingress routing.
    /// Called from the event stream subscription loop.
    pub async fn handle(
        &self,
        event_type: &str,
        payload: &serde_json::Value,
    ) -> Result<()> {
        match event_type {
            "IngressCreated" | "IngressUpdated" => {
                self.on_ingress_upserted(payload).await?;
            }
            "IngressDeleted" => {
                self.on_ingress_deleted(payload).await?;
            }
            "WorkloadRescheduled" => {
                self.on_workload_rescheduled(payload).await?;
            }
            _ => {}
        }
        Ok(())
    }

    async fn on_ingress_upserted(&self, payload: &serde_json::Value) -> Result<()> {
        // TODO: extract ingress details from payload
        // Build RouteEntry from payload fields:
        //   ingress_iri, product, target workload_iri, upstream address+port,
        //   path_prefix, internal flag

        // Issue TLS cert for the hostname if external
        // let hostname = payload["host"].as_str().unwrap_or_default();
        // if !payload["internal"].as_bool().unwrap_or(false) {
        //     self.tls.write()?.ensure_cert(hostname).await?;
        // }

        // Upsert the route
        // let entry = RouteEntry { ... };
        // let internal = payload["internal"].as_bool().unwrap_or(false);
        // self.router.write()?.upsert(entry, internal);

        tracing::info!("Ingress route upserted");
        Ok(())
    }

    async fn on_ingress_deleted(&self, payload: &serde_json::Value) -> Result<()> {
        // TODO: extract ingress_iri and hostname from payload
        // self.router.write()?.remove(&ingress_iri);
        // self.tls.write()?.remove_cert(&hostname);

        tracing::info!("Ingress route removed");
        Ok(())
    }

    async fn on_workload_rescheduled(&self, payload: &serde_json::Value) -> Result<()> {
        // TODO: extract workload_iri and new node address from payload
        // self.router.write()?.update_upstream(&workload_iri, new_address);

        tracing::info!("Ingress upstream address updated after workload reschedule");
        Ok(())
    }
}

/// Events that the ingress handler subscribes to.
/// Used to filter the platform event stream.
pub const SUBSCRIBED_EVENTS: &[&str] = &[
    "IngressCreated",
    "IngressUpdated",
    "IngressDeleted",
    "WorkloadRescheduled",
    "WorkloadFailed",
];
