/// .picloud → Turtle Compiler
///
/// Translates parsed .picloud AST nodes into Turtle RDF triples.
/// Every nested structure gets a stable, dereferenceable IRI — no blank nodes.
///
/// IRI generation rules (ADR-049):
///   {parent}/{property}          for singleton nested objects
///   {parent}/{property}/{key}    for keyed collections (tags, mounts by volume name)
///   {parent}/{property}/{index}  for ordered lists
///
/// The same .picloud files always produce the same IRIs.
/// Diffs are meaningful. SPARQL queries always work.

use picloud_domain::error::{PiCloudError, Result};
use picloud_domain::iri::{ClusterDomain, IriBuilder};
use crate::parser::{ParsedFile, ResourceDecl, PropertyValue};

/// The result of compiling one or more .picloud files
pub struct CompileResult {
    /// Turtle representation ready for the merger
    pub turtle: String,
    /// IRIs produced — for cross-reference validation
    pub declared_iris: Vec<String>,
}

/// Compile a parsed .picloud file to Turtle
pub fn compile(file: &ParsedFile, domain: &ClusterDomain) -> Result<CompileResult> {
    let builder = IriBuilder::new(domain.clone());
    let mut output = TurtleWriter::new();

    output.prefix("pc",  "https://picloud.local/ontology#");
    output.prefix("xsd", "http://www.w3.org/2001/XMLSchema#");

    let mut declared_iris = Vec::new();

    for resource in &file.resources {
        let iri = resource_iri(&builder, resource)?;
        declared_iris.push(iri.clone());
        compile_resource(&mut output, resource, &iri, &builder)?;
    }

    Ok(CompileResult {
        turtle:        output.finish(),
        declared_iris,
    })
}

fn resource_iri(builder: &IriBuilder, resource: &ResourceDecl) -> Result<String> {
    // Extract product from properties
    let product = resource.properties.iter()
        .find(|p| p.key == "product")
        .and_then(|p| if let PropertyValue::String(s) = &p.value { Some(s.as_str()) } else { None });

    match resource.resource_type.as_str() {
        "product" => Ok(builder.product(&resource.name).to_string()),
        "container" => {
            let product = product.ok_or_else(|| {
                PiCloudError::ResourceValidationFailed {
                    reason: format!("Container '{}' missing required property: product", resource.name),
                }
            })?;
            Ok(builder.resource(product, "containers", &resource.name).to_string())
        }
        "volume" => {
            let product = product.ok_or_else(|| {
                PiCloudError::ResourceValidationFailed {
                    reason: format!("Volume '{}' missing required property: product", resource.name),
                }
            })?;
            Ok(builder.resource(product, "volumes", &resource.name).to_string())
        }
        "feature-flag" => {
            let product = product.ok_or_else(|| {
                PiCloudError::ResourceValidationFailed {
                    reason: format!("FeatureFlag '{}' missing required property: product", resource.name),
                }
            })?;
            Ok(builder.feature_flag(product, &resource.name).to_string())
        }
        "inference-rule" => {
            let product = product.ok_or_else(|| {
                PiCloudError::ResourceValidationFailed {
                    reason: format!("InferenceRule '{}' missing required property: scope or product", resource.name),
                }
            })?;
            Ok(builder.resource(product, "inference-rules", &resource.name).to_string())
        }
        "role" => {
            let product = product.ok_or_else(|| PiCloudError::ResourceValidationFailed {
                reason: format!("Role '{}' missing required property: product", resource.name),
            })?;
            Ok(builder.resource(product, "roles", &resource.name).to_string())
        }
        "scope" => {
            let product = product.ok_or_else(|| PiCloudError::ResourceValidationFailed {
                reason: format!("Scope '{}' missing required property: product", resource.name),
            })?;
            Ok(builder.resource(product, "scopes", &resource.name).to_string())
        }
        "m2m-permission" => {
            let product = product.ok_or_else(|| PiCloudError::ResourceValidationFailed {
                reason: format!("M2mPermission '{}' missing required property: product", resource.name),
            })?;
            Ok(builder.resource(product, "m2m-permissions", &resource.name).to_string())
        }
            reason: format!("Unknown resource type: '{}'", other),
        }),
    }
}

fn compile_resource(
    out:      &mut TurtleWriter,
    resource: &ResourceDecl,
    iri:      &str,
    builder:  &IriBuilder,
) -> Result<()> {
    let rdf_type = resource_rdf_type(&resource.resource_type);
    out.triple(iri, "a", &format!("pc:{}", rdf_type));

    for prop in &resource.properties {
        compile_property(out, resource, iri, &prop.key, &prop.value, builder)?;
    }

    out.blank_line();
    Ok(())
}

fn compile_property(
    out:           &mut TurtleWriter,
    resource:      &ResourceDecl,
    parent_iri:    &str,
    key:           &str,
    value:         &PropertyValue,
    builder:       &IriBuilder,
) -> Result<()> {
    match value {
        PropertyValue::String(s)  => out.triple(parent_iri, &format!("pc:{}", camel(key)), &format!("\"{}\"", s)),
        PropertyValue::Number(n)  => out.triple(parent_iri, &format!("pc:{}", camel(key)), &n.to_string()),
        PropertyValue::Bool(b)    => out.triple(parent_iri, &format!("pc:{}", camel(key)), &b.to_string()),
        PropertyValue::Secret(s)  => out.triple(parent_iri, &format!("pc:{}", camel(key)), &format!("\"secret:{}\"", s)),

        PropertyValue::Block(props) => {
            // Stable IRI for the nested object: {parent}/{property-name}
            let nested_iri = format!("{}/{}", parent_iri, key);
            out.triple(parent_iri, &format!("pc:{}", camel(key)), &nested_iri);

            // Infer rdf:type for well-known nested types
            if let Some(t) = nested_rdf_type(key) {
                out.triple(&nested_iri, "a", &format!("pc:{}", t));
            }

            for prop in props {
                compile_property(out, resource, &nested_iri, &prop.key, &prop.value, builder)?;
            }
            out.blank_line();
        }

        PropertyValue::Blocks(blocks) => {
            // Repeated blocks: tags, mounts etc.
            // Key for each block is derived from the block's own "key" or "volume" property,
            // falling back to index for unnamed blocks
            for (i, props) in blocks.iter().enumerate() {
                let block_key = props.iter()
                    .find(|p| p.key == "key" || p.key == "volume" || p.key == "name")
                    .and_then(|p| if let PropertyValue::String(s) = &p.value { Some(s.as_str()) } else { None })
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| i.to_string());

                let nested_iri = format!("{}/{}/{}", parent_iri, key, block_key);
                out.triple(parent_iri, &format!("pc:{}", camel(key)), &nested_iri);

                if let Some(t) = nested_rdf_type(key) {
                    out.triple(&nested_iri, "a", &format!("pc:{}", t));
                }

                for prop in props {
                    compile_property(out, resource, &nested_iri, &prop.key, &prop.value, builder)?;
                }
                out.blank_line();
            }
        }
    }
    Ok(())
}

/// Map resource type names to RDF class names
fn resource_rdf_type(resource_type: &str) -> &str {
    match resource_type {
        "product"        => "Product",
        "container"      => "Container",
        "volume"         => "Volume",
        "binary"         => "Binary",
        "rdf-store"      => "RdfStore",
        "event-store"    => "EventStore",
        "feature-flag"   => "FeatureFlag",
        "inference-rule" => "InferenceRule",
        "ingress"        => "Ingress",
        "config"         => "ConfigStore",
        "ontology"       => "Ontology",
        "group"          => "Group",
        "role"             => "ProductRole",
        "scope"            => "ProductScope",
        "m2m-permission"   => "M2mPermission",
    }
}

/// Map nested property block names to RDF class names
fn nested_rdf_type(key: &str) -> Option<&str> {
    match key {
        "snapshots"  => Some("SnapshotConfig"),
        "retention"  => Some("SnapshotRetention"),
        "offsite"    => Some("OffsiteBackupConfig"),
        "mount"      => Some("VolumeMount"),
        "tag"        => Some("Tag"),
        "otel"       => Some("OtelConfig"),
        "resources"  => Some("ResourceLimits"),
        _            => None,
    }
}

/// Convert kebab-case property names to camelCase for RDF predicates
fn camel(s: &str) -> String {
    let mut result = String::new();
    let mut capitalise = false;
    for c in s.chars() {
        if c == '-' {
            capitalise = true;
        } else if capitalise {
            result.push(c.to_ascii_uppercase());
            capitalise = false;
        } else {
            result.push(c);
        }
    }
    result
}

/// Simple Turtle writer — accumulates triples into a string
struct TurtleWriter {
    lines: Vec<String>,
}

impl TurtleWriter {
    fn new() -> Self { Self { lines: Vec::new() } }

    fn prefix(&mut self, prefix: &str, iri: &str) {
        self.lines.push(format!("@prefix {}: <{}> .", prefix, iri));
    }

    fn triple(&mut self, subject: &str, predicate: &str, object: &str) {
        self.lines.push(format!("<{}> {} {} .", subject, predicate, object));
    }

    fn blank_line(&mut self) {
        self.lines.push(String::new());
    }

    fn finish(self) -> String {
        self.lines.join("\n")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn camel_conversion() {
        assert_eq!(camel("feature-flag"),   "featureFlag");
        assert_eq!(camel("rdf-store"),      "rdfStore");
        assert_eq!(camel("max-upload-mb"),  "maxUploadMb");
        assert_eq!(camel("image"),          "image");
    }
}
