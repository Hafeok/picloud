/// SHACL Validator
///
/// Validates a compiled deployment graph against the platform
/// SHACL shapes. Translates raw SHACL violation reports into
/// developer-friendly error messages (ADR-049).
///
/// Two modes:
///   offline — validates against local platform ontology copy
///   online  — also checks cross-resource references against live cluster

use picloud_domain::error::{PiCloudError, Result};

/// The result of validating a deployment graph
#[derive(Debug, Clone)]
pub struct ValidationResult {
    pub valid:    bool,
    pub errors:   Vec<ValidationError>,
    pub warnings: Vec<ValidationWarning>,
}

impl ValidationResult {
    pub fn ok() -> Self {
        Self { valid: true, errors: Vec::new(), warnings: Vec::new() }
    }

    pub fn print_report(&self) {
        if self.valid {
            println!("✓ Validation passed");
        } else {
            println!("✗ Validation failed — {} error(s)", self.errors.len());
        }
        for e in &self.errors   { eprintln!("  error:   {}", e.message); }
        for w in &self.warnings { println!("  warning: {}", w.message); }
    }
}

/// A human-readable validation error — translated from SHACL violations
#[derive(Debug, Clone)]
pub struct ValidationError {
    pub message:      String,
    /// The IRI of the resource that failed validation
    pub resource_iri: Option<String>,
    /// The property that failed
    pub property:     Option<String>,
    /// Source file and line, if known
    pub location:     Option<String>,
}

#[derive(Debug, Clone)]
pub struct ValidationWarning {
    pub message:      String,
    pub resource_iri: Option<String>,
}

/// Validate a Turtle deployment graph against the platform SHACL shapes.
/// Uses the local copy of the platform ontology — no cluster required.
pub fn validate_offline(turtle: &str, shapes_ttl: &str) -> Result<ValidationResult> {
    // TODO: implement SHACL validation via Oxigraph
    //
    // Steps:
    // 1. Load deployment graph into Oxigraph named graph
    // 2. Load platform SHACL shapes into Oxigraph
    // 3. Run SHACL validation
    // 4. Translate violations to ValidationError using translate_violation()
    //
    // Oxigraph supports SHACL validation natively — this is a thin wrapper

    tracing::info!("Running offline SHACL validation");
    Ok(ValidationResult::ok())
}

/// Validate cross-resource references against a live cluster.
/// Called after validate_offline succeeds.
pub async fn validate_online(
    turtle:      &str,
    cluster_url: &str,
    token:       &str,
) -> Result<ValidationResult> {
    // TODO: implement online validation
    //
    // Cross-resource checks:
    // - Referenced secrets exist in cluster secret store
    // - Referenced identities exist in cluster IAM
    // - Product version is compatible with currently deployed version
    // - NAS/S3 secrets are reachable (optional connectivity check)

    tracing::info!(cluster = %cluster_url, "Running online cross-reference validation");
    Ok(ValidationResult::ok())
}

/// Translate a SHACL violation into a human-readable error message.
/// Called for each sh:ValidationResult in the SHACL report.
fn translate_violation(
    focus_node:       &str,
    property_path:    &str,
    constraint_class: &str,
    message:          Option<&str>,
) -> ValidationError {
    // Extract resource name from IRI for readable messages
    let resource_name = focus_node
        .rsplit('/')
        .next()
        .unwrap_or(focus_node);

    // Extract property name from predicate IRI
    let property_name = property_path
        .rsplit(['/', '#'])
        .next()
        .unwrap_or(property_path);

    // Map SHACL constraint classes to readable explanations
    let explanation = match constraint_class {
        "MinCountConstraintComponent" =>
            format!("required property '{}' is missing", property_name),
        "MaxCountConstraintComponent" =>
            format!("property '{}' appears too many times", property_name),
        "DatatypeConstraintComponent" =>
            format!("'{}' has the wrong type", property_name),
        "InConstraintComponent" =>
            format!("'{}' has an invalid value", property_name),
        "PatternConstraintComponent" =>
            format!("'{}' does not match the required pattern", property_name),
        "MinInclusiveConstraintComponent" | "MinExclusiveConstraintComponent" =>
            format!("'{}' is below the minimum allowed value", property_name),
        "MaxInclusiveConstraintComponent" | "MaxExclusiveConstraintComponent" =>
            format!("'{}' exceeds the maximum allowed value", property_name),
        "NodeKindConstraintComponent" =>
            format!("'{}' must be an IRI reference", property_name),
        other =>
            format!("'{}' failed constraint: {}", property_name, other),
    };

    // Use sh:message if provided by the shape author — more specific
    let message = message
        .map(|m| format!("{}: {}", resource_name, m))
        .unwrap_or_else(|| format!("{}: {}", resource_name, explanation));

    ValidationError {
        message,
        resource_iri: Some(focus_node.to_string()),
        property:     Some(property_name.to_string()),
        location:     None,
    }
}
