/// .picloud Surface Format Parser
///
/// Parses .picloud files into an intermediate AST.
/// The AST is then compiled to Turtle by compiler.rs.
///
/// .picloud syntax is a simplified, readable surface over Turtle:
///   - Block syntax instead of subject-predicate-object triples
///   - Unquoted property names
///   - String, number, boolean literals
///   - Nested blocks for complex properties
///   - secret("name") references
///
/// Example:
///   container "api-server" {
///     product  = "photo-app"
///     image    = "photo-api:1.0.0"
///     mount {
///       volume = "media-store"
///       path   = "/data"
///     }
///   }

use picloud_domain::error::{PiCloudError, Result};

/// A parsed .picloud file — a list of resource declarations
#[derive(Debug, Clone)]
pub struct ParsedFile {
    pub path:      String,
    pub resources: Vec<ResourceDecl>,
}

/// A single resource declaration
#[derive(Debug, Clone)]
pub struct ResourceDecl {
    /// Resource type (e.g. "container", "volume", "feature-flag")
    pub resource_type: String,
    /// Resource name (e.g. "api-server")
    pub name: String,
    /// Property assignments
    pub properties: Vec<Property>,
    /// Line number in source file — for error messages
    pub line: usize,
}

/// A property assignment within a resource block
#[derive(Debug, Clone)]
pub struct Property {
    pub key:   String,
    pub value: PropertyValue,
    pub line:  usize,
}

/// A property value — scalar, nested block, or secret reference
#[derive(Debug, Clone)]
pub enum PropertyValue {
    String(String),
    Number(f64),
    Bool(bool),
    /// secret("name") — resolved at deploy time via platform secret store
    Secret(String),
    /// Nested block (e.g. mount { ... }, snapshots { ... })
    Block(Vec<Property>),
    /// Repeated block (e.g. multiple tag { ... } entries)
    Blocks(Vec<Vec<Property>>),
}

/// Parse a .picloud file from a string
pub fn parse(source: &str, path: &str) -> Result<ParsedFile> {
    // TODO: implement parser
    // Phase 1 approach: hand-written recursive descent parser
    // The syntax is simple enough that a parser combinator library
    // (nom or winnow, both pure Rust) would be overkill for MVP
    //
    // Key tokens:
    //   IDENT   ::= [a-zA-Z][a-zA-Z0-9-_]*
    //   STRING  ::= '"' [^"]* '"'
    //   NUMBER  ::= [0-9]+ ('.' [0-9]+)?
    //   BOOL    ::= 'true' | 'false'
    //   SECRET  ::= 'secret' '(' STRING ')'
    //   BLOCK   ::= '{' (IDENT '=' VALUE | IDENT BLOCK)* '}'
    //   RESOURCE::= IDENT STRING BLOCK
    //   FILE    ::= RESOURCE*

    Err(PiCloudError::Internal("parser not yet implemented".into()))
}

/// Parse a directory of .picloud and .ttl files
pub fn parse_directory(path: &str) -> Result<Vec<ParsedFile>> {
    // Walk directory, parse .picloud files with parse()
    // .ttl files are passed through to the merger directly
    Err(PiCloudError::Internal("directory parser not yet implemented".into()))
}
