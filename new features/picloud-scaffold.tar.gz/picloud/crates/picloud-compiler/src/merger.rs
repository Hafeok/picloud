/// Graph Merger
///
/// Merges compiled Turtle output from multiple .picloud and .ttl files
/// into a single deployment graph.
///
/// The merged graph is what gets SHACL-validated and submitted to the cluster.
/// .picloud files are never submitted — only the merged deployment.ttl.
///
/// Conflict detection:
///   If two files declare the same IRI with conflicting triples,
///   the merger reports an error before the graph is submitted.

use picloud_domain::error::{PiCloudError, Result};
use crate::compiler::CompileResult;

/// A merged deployment graph ready for SHACL validation and submission
pub struct DeploymentGraph {
    /// The complete merged Turtle graph
    pub turtle:        String,
    /// All IRIs declared across all input files
    pub declared_iris: Vec<String>,
    /// Source files that contributed to this graph
    pub sources:       Vec<String>,
}

/// Merge compiled Turtle outputs and raw .ttl files into one graph
pub fn merge(
    compiled:  Vec<CompileResult>,
    raw_ttl:   Vec<RawTtlFile>,
) -> Result<DeploymentGraph> {
    let mut all_turtle   = Vec::new();
    let mut declared_iris = Vec::new();
    let mut sources       = Vec::new();

    // Collect compiled outputs
    for result in compiled {
        all_turtle.push(result.turtle);
        declared_iris.extend(result.declared_iris);
    }

    // Collect raw .ttl files (passed through unchanged)
    for raw in raw_ttl {
        sources.push(raw.path.clone());
        all_turtle.push(raw.content);
    }

    // TODO: detect IRI conflicts
    // If the same subject IRI appears in multiple files with
    // conflicting property values, report a MergeConflict error.
    // For now, last-write-wins (Oxigraph behaviour on load).

    let merged_turtle = all_turtle.join("\n\n");

    Ok(DeploymentGraph {
        turtle: merged_turtle,
        declared_iris,
        sources,
    })
}

pub struct RawTtlFile {
    pub path:    String,
    pub content: String,
}

/// Write the merged deployment graph to a file
pub fn write_deployment(graph: &DeploymentGraph, output_path: &str) -> Result<()> {
    std::fs::write(output_path, &graph.turtle)
        .map_err(|e| PiCloudError::Internal(format!(
            "Failed to write deployment graph to {}: {}", output_path, e
        )))
}
